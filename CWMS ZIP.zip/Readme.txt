How to run the  Project Using PHP and MySQL

2. Extract the file and copy cwms folder
3.Paste inside root directory(for xampp xampp/htdocs)
4. Open PHPMyAdmin (http://localhost/phpmyadmin)
5. Create a database with name cwms
6. Import cwms.sql file(given inside the zip package in SQL file folder)
7.Run the script http://localhost/cwms (frontend)
Login Details
Login Details for admin: Username:zakaria@gmail.com
                         Password:12345
Login Details for Users: Username:Malulu12@gmail.com
                         Password:12345@ 
                         OR Register New User


