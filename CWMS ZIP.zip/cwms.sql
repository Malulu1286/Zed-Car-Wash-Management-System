-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 14, 2025 at 08:09 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cwms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `admin_name`, `email`, `password`, `created_at`) VALUES
(1, 'Zakaria', 'zakaria@gmail.com', '$2y$10$0ipES1xPSy/cGJDLih.pSu75mgbCb3gduzbuliyBC6bFlvfIInqhG', '2025-06-11 06:30:19');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `booking_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `appointment_date` datetime NOT NULL,
  `status` enum('Pending','Completed','Cancelled') DEFAULT 'Pending',
  `tx_ref` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `payment_method` varchar(50) NOT NULL,
  `mobile_number` varchar(20) DEFAULT NULL,
  `card_number_last4` varchar(4) DEFAULT NULL,
  `card_number` varchar(20) DEFAULT NULL,
  `card_expiry` varchar(10) DEFAULT NULL,
  `card_cvv` varchar(5) DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `customer_email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`booking_id`, `customer_id`, `service_id`, `appointment_date`, `status`, `tx_ref`, `created_at`, `payment_method`, `mobile_number`, `card_number_last4`, `card_number`, `card_expiry`, `card_cvv`, `customer_name`, `customer_phone`, `customer_email`) VALUES
(51, 36, 8, '2025-06-27 16:09:00', 'Completed', NULL, '2025-06-27 08:10:07', 'Mobile Payment', NULL, NULL, NULL, NULL, NULL, 'malulu', '0788997788', 'malulu12@gmail.com'),
(65, 36, 11, '2025-07-01 18:57:00', 'Completed', NULL, '2025-06-30 16:01:06', 'Mobile Payment', '0764679436', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(66, 36, 2, '2025-07-01 19:05:00', '', NULL, '2025-06-30 16:06:14', 'Card', '', '6800', NULL, NULL, NULL, NULL, NULL, NULL),
(68, 17, 21, '2025-07-02 12:26:00', '', NULL, '2025-07-01 09:27:15', 'Card', '', '7890', NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `customer_phone` varchar(15) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_admin` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `customer_name`, `customer_phone`, `email`, `password`, `created_at`, `is_admin`) VALUES
(17, 'Zakaria Malulu ', '0768679436', 'zakariamalulu12@gmail.com', '$2y$10$CoWtjOB6jB4gD3KwNsSW9O5yy7kAo.4QdRKCIVNPl5faPUeO6tCAK', '2025-05-09 20:42:15', 1),
(19, 'milka', '0789898980', 'milka@gmail.com', '', '2025-05-12 15:22:15', 1),
(34, 'malulu', '07888877', 'malulu@gmail.com', '$2y$10$J0WTSCeMdJoAZGHEJoSWbOosFCtJzQlNUk8L10WPQQ9Do0GYMxE9i', '2025-06-24 18:31:01', 1),
(35, 'joshua', '0788448833', 'joshua@gmail.com', '$2y$10$sf1Slu4fuuh1UreDpEHBZOsZ40A5tIof7BrsFhIHgRx2LrWXS96hm', '2025-06-24 18:42:48', 1),
(36, 'malulu', '0697488844', 'malulu12@gmail.com', '$2y$10$qQUqhnSVrS81c/arT5IJz.OxFYS4TrE/M5lFHYJFi90a/2RQxPvO6', '2025-06-25 08:43:40', 1);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `name`, `email`, `message`, `created_at`) VALUES
(5, 'juma nature ', 'jumaa@gmail.com', 'Huduma nzuri', '2025-04-18 17:00:28'),
(6, 'Zakariamalulu12 ', 'zakariamalulu12@gmail.com', 'Good Services guys\r\n', '2025-05-01 09:58:50'),
(9, 'FahFahad ', 'fahad@gmail.com', 'Keep going \r\n', '2025-05-09 20:33:27'),
(10, 'Madam Kileo ', 'kileo@gmail.com', 'Huduma Nzuri Sana\r\nhongerenii!!!!!!', '2025-05-11 19:27:24');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `service_name` varchar(100) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `control_number` varchar(20) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `service_name`, `amount`, `customer_name`, `phone`, `email`, `control_number`, `status`, `created_at`) VALUES
(1, 'Full Wash', 20000, 'malulu', '0697488844', 'malulu12@gmail.com', 'ZED402259', 'Pending', '2025-06-25 19:17:24'),
(2, 'Scania', 30000, 'malulu', '0697488844', 'malulu12@gmail.com', 'ZED855746', 'Pending', '2025-06-25 19:21:52'),
(3, 'Basic Wash', 15000, 'malulu', '0697488844', 'malulu12@gmail.com', 'ZED930566', 'Pending', '2025-06-25 19:33:38');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `service_id` int(11) NOT NULL,
  `service_name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`service_id`, `service_name`, `price`, `description`) VALUES
(1, 'Basic Wash', 10000.00, 'Exterior cleaning only'),
(2, 'Full Wash', 20000.00, 'Exterior and interior cleaning'),
(8, 'Motorcycles Wash', 5000.00, 'Full Cleaning'),
(11, 'scania', 30000.00, 'chassis Cleaning '),
(20, 'Premium Wash', 30000.00, 'exterior and interior wash including waxing'),
(21, 'full cleaning ', 35000.00, 'interior and exterior plus waxing'),
(22, 'Bus Full Washing ', 50000.00, 'interior and exterior wash plus waxing ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`booking_id`),
  ADD UNIQUE KEY `tx_ref` (`tx_ref`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `service_id` (`service_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`),
  ADD UNIQUE KEY `phone_number` (`customer_phone`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`service_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `service_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`service_id`) REFERENCES `services` (`service_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
