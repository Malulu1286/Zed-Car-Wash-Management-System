<?php
session_start();
session_destroy();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Logging Out</title>
  <meta http-equiv="refresh" content="2;url=index.php" />
  
  <!-- Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <!-- AOS CSS -->
  <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet" />
  <!-- FontAwesome CSS -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />
  
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f8f9fa;
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0;
      color: #333;
      position: relative;
    }
    .logout-box {
      background: #fff;
      padding: 3rem 3.5rem;
      border-radius: 1rem;
      box-shadow: 0 0.75rem 1.5rem rgba(0, 0, 0, 0.1);
      max-width: 400px;
      width: 90%;
      text-align: center;
    }
    h2 {
      color: #00bfff;
      font-weight: 600;
      margin-bottom: 1rem;
    }
    p {
      color: #555;
      font-size: 1rem;
    }
    .spinner-border {
      width: 3rem;
      height: 3rem;
      border-width: 0.4rem;
      color: #00bfff;
      margin: 1.5rem auto;
      display: block;
    }
    footer {
      position: absolute;
      bottom: 1rem;
      width: 100%;
      text-align: center;
      color: #666;
      font-size: 0.9rem;
      user-select: none;
    }
    @media (max-width: 600px) {
      .logout-box {
        padding: 2rem 1.5rem;
      }
      h2 {
        font-size: 1.5rem;
      }
      .spinner-border {
        width: 2rem;
        height: 2rem;
        border-width: 0.3rem;
      }
    }
  </style>
</head>
<body>
  
  <div class="logout-box" data-aos="fade-up" role="alert" aria-live="polite" aria-busy="true" tabindex="0">
    <h2><i class="fas fa-sign-out-alt me-2"></i>Logging out...</h2>
    <div class="spinner-border" role="status" aria-label="Loading spinner"></div>
    <p>You will be redirected to the <strong>homepage</strong> shortly.</p>
  </div>
  
  <footer>
    &copy; 2025 Zed Group of Companies
  </footer>
  
  <!-- Bootstrap 5 JS Bundle -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <!-- AOS JS -->
  <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
  <script>
    AOS.init({
      duration: 800,
      once: true
    });
  </script>
</body>
</html>
