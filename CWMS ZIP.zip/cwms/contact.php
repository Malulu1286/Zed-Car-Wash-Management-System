<?php
include 'includes/config.php';

$success = "";
$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if (empty($name) || empty($email) || empty($message)) {
        $error = "Please fill in all required fields (name, email, and message).";
    } else {
        try {
            $stmt = $dbh->prepare("INSERT INTO messages (name, email, phone, subject, message) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$name, $email, $phone, $subject, $message]);
            $success = "Your message has been sent successfully!";
        } catch (PDOException $e) {
            $error = "An error occurred: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Contact Us - Zed Car Wash</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet" />
  <style>
    body {
      font-family: 'Inter', sans-serif;
      background: #f5f9ff;
    }
    .navbar {
      background: white;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
    }
    .nav-link {
      color: #00bfff !important;
      font-weight: 600;
    }
    .nav-link:hover {
      color: #007acc !important;
    }
    .card {
      background-color: #ffffff;
      border-radius: 16px;
      box-shadow: 0 12px 30px rgba(0, 191, 255, 0.1);
      padding: 40px;
      border: none;
    }
    h2 {
      color: #00bfff;
      font-weight: 700;
    }
    label.form-label {
      font-weight: 600;
    }
    .form-control:focus {
      border-color: #00bfff;
      box-shadow: 0 0 0 0.2rem rgba(0, 191, 255, 0.25);
    }
    .btn-info {
      background-color: #00bfff;
      border: none;
    }
    .btn-info:hover {
      background-color: #0095cc;
    }
    footer {
      background: #f0f0f0;
      padding: 20px;
      text-align: center;
      font-size: 0.95rem;
      color: #555;
      margin-top: 80px;
    }
    a.text-success:hover,
    a.text-danger:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light px-4 py-3">
  <div class="container-fluid">
    <a class="navbar-brand fw-bold text-info" href="#"><i class="fas fa-car me-2"></i>Zed Car Wash</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navContent">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-end" id="navContent">
      <ul class="navbar-nav gap-2">
        <li class="nav-item"><a class="nav-link" href="index.php"><i class="fas fa-home me-1"></i>Home</a></li>
        <li class="nav-item"><a class="nav-link" href="services.php"><i class="fas fa-cogs me-1"></i>Services</a></li>
        <li class="nav-item"><a class="nav-link" href="user/user_dashboard.php"><i class="fas fa-user me-1"></i>User</a></li>
        <li class="nav-item"><a class="nav-link" href="admin/admin_dashboard.php"><i class="fas fa-lock me-1"></i>Admin</a></li>
        <li class="nav-item"><a class="nav-link active" href="contact.php"><i class="fas fa-envelope me-1"></i>Contact</a></li>
        <li class="nav-item"><a class="nav-link" href="about.php"><i class="fas fa-info-circle me-1"></i>About</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Main Container -->
<div class="container my-5" data-aos="fade-up">
  <div class="row justify-content-center">
    <div class="col-lg-10">
      <div class="card">
        <h2 class="text-center mb-4"><i class="fas fa-envelope me-2"></i>Contact Us</h2>

        <?php if ($success): ?>
          <div class="alert alert-success"><i class="fas fa-check-circle me-2"></i><?= $success; ?></div>
        <?php elseif ($error): ?>
          <div class="alert alert-danger"><i class="fas fa-exclamation-circle me-2"></i><?= $error; ?></div>
        <?php endif; ?>

        <div class="row g-4">
          <div class="col-md-6" data-aos="fade-right">
            <h5 class="text-info"><i class="fas fa-map-marker-alt me-2"></i>Address</h5>
            <p>123 Njiro, Arusha, Tanzania</p>

            <h5 class="text-info"><i class="fas fa-phone me-2"></i>Phone</h5>
            <p>+255 768 679 436<br>+255 764 679 436</p>

            <h5 class="text-info"><i class="fas fa-envelope me-2"></i>Email</h5>
            <p>zedgroup255@gmail.com<br>zakariamalulu12@gmail.com</p>

            <h5 class="text-info"><i class="fab fa-whatsapp me-2"></i>WhatsApp</h5>
            <p>
              <a href="https://wa.me/255768679436?text=Hello%20Zed%20Car%20Wash!" target="_blank" class="text-decoration-none text-success">
                <i class="fab fa-whatsapp me-1"></i>Chat on WhatsApp
              </a>
            </p>

            <h5 class="text-info"><i class="fab fa-instagram me-2"></i>Instagram</h5>
            <p>
              <a href="https://instagram.com/zed_grouptz" target="_blank" class="text-decoration-none text-danger">
                <i class="fab fa-instagram me-1"></i>Follow us on Instagram
              </a>
            </p>
          </div>

          <div class="col-md-6" data-aos="fade-left">
            <form method="POST" action="">
              <div class="mb-3">
                <label for="name" class="form-label">Full Name *</label>
                <input type="text" class="form-control" id="name" name="name" required>
              </div>
              <div class="mb-3">
                <label for="email" class="form-label">Email *</label>
                <input type="email" class="form-control" id="email" name="email" required>
              </div>
              <div class="mb-3">
                <label for="phone" class="form-label">Phone</label>
                <input type="text" class="form-control" id="phone" name="phone" placeholder="+255 768 679 436">
              </div>
              <div class="mb-3">
                <label for="message" class="form-label">Message *</label>
                <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
              </div>
              <button type="submit" class="btn btn-info w-100 text-white fw-semibold"><i class="fas fa-paper-plane me-2"></i>Send Message</button>
            </form>
          </div>
        </div>

        <div class="mt-5" data-aos="fade-up">
          <h5 class="text-center mb-3"><i class="fas fa-map me-2"></i>Our Location</h5>
          <iframe src="https://maps.google.com/maps?q=IAA-Arusha&t=&z=13&ie=UTF8&iwloc=&output=embed"
                  style="width: 100%; height: 300px; border-radius: 12px; border: 1px solid #ccc;"></iframe>
        </div>
      </div>
    </div>
  </div>
</div>

<footer>
  <p>&copy; 2025 Zed Group of Companies. All rights reserved.</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init({ duration: 1000, once: true });
</script>
</body>
</html>
