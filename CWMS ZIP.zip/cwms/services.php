<?php
include 'includes/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Services - Zed Car Wash</title>

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- FontAwesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <!-- AOS -->
  <link href="https://unpkg.com/aos@2.3.4/dist/aos.css" rel="stylesheet" />
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

  <style>
    /* Your existing styles here, unchanged */
    body {
      font-family: 'Inter', sans-serif;
      background: #fff;
      background-size: cover;
      color: #333;
      min-height: 100vh;
      position: relative;
    }

    .overlay {
      background: rgba(255, 255, 255, 0.95);
      min-height: 100vh;
      padding-bottom: 60px;
    }

    header {
      background-color: #f8f9fa;
      padding: 20px 40px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      border-bottom: 2px solid #00bfff;
    }

    header h1 {
      color: #00bfff;
      font-weight: 700;
      font-size: 1.8rem;
    }

    nav a {
      color: #007bff;
      font-weight: 600;
      margin: 0 12px;
      text-decoration: none;
    }

    nav a:hover {
      text-decoration: underline;
    }

    .glass-section {
      background-color: #fff;
      padding: 50px 30px;
      border-radius: 15px;
      box-shadow: 0 12px 30px rgba(0, 0, 0, 0.1);
      max-width: 1100px;
      margin: 60px auto;
    }

    .card {
      background-color: #f8f9fa;
      border: 1px solid #e3e3e3;
      border-radius: 15px;
      transition: all 0.3s ease;
    }

    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 20px rgba(0, 191, 255, 0.2);
    }

    .btn-book {
      background-color: #00bfff;
      color: #fff;
      font-weight: 600;
      border-radius: 25px;
    }

    .btn-book:hover {
      background-color: #0095cc;
    }

    footer {
      background-color: #f1f1f1;
      padding: 20px;
      text-align: center;
      color: #555;
      font-size: 0.95rem;
    }

    @media (max-width: 768px) {
      header {
        flex-direction: column;
        align-items: flex-start;
      }

      nav {
        margin-top: 10px;
      }
    }
  </style>
</head>
<body>
  <div class="overlay">
    <header>
      <h1><i class="fas fa-car"></i> Zed Car Wash</h1>
      <nav>
        <a href="index.php"><i class="fas fa-home"></i> Home</a>
        <a href="user/user_dashboard.php"><i class="fas fa-user"></i> User</a>
        <a href="admin/admin_dashboard.php"><i class="fas fa-user-shield"></i> Admin</a>
        <a href="contact.php"><i class="fas fa-envelope"></i> Contact</a>
        <a href="about.php"><i class="fas fa-info-circle"></i> About</a>
      </nav>
    </header>

    <div class="container glass-section" data-aos="fade-up">
      <h2 class="text-center mb-5 text-primary"><i class="fas fa-broom"></i> Our Car Wash Services</h2>
      <div class="row g-4">
        <?php
        try {
            $stmt = $dbh->query("SELECT service_name, description, price FROM services ORDER BY service_name ASC");
            $services = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            if ($services) {
                foreach ($services as $service) {
                    $serviceNameEncoded = urlencode($service['service_name']);
                    $priceFormatted = number_format($service['price'], 2);
                    echo '
                    <div class="col-md-6 col-lg-4" data-aos="zoom-in">
                      <div class="card p-4 h-100">
                        <h5><i class="fas fa-check-circle text-success"></i> ' . htmlspecialchars($service['service_name']) . '</h5>
                        <p>' . nl2br(htmlspecialchars($service['description'])) . '</p>
                        <p><strong>Price:</strong> ' . $priceFormatted . ' TZS</p>
                        <a href="explore_service.php?service=' . $serviceNameEncoded . '" class="btn btn-book btn-sm">
                          <i class="fas fa-calendar-check"></i> explore service
                        </a>
                      </div>
                    </div>';
                }
            } else {
                echo '<p class="text-center text-muted">No services found.</p>';
            }
        } catch (PDOException $e) {
            echo '<p class="text-danger">Error fetching services: ' . htmlspecialchars($e->getMessage()) . '</p>';
        }
        ?>
      </div>
    </div>

    <footer>
      <p>&copy; 2025 Zed Group of Companies. All Rights Reserved.</p>
    </footer>
  </div>

  <!-- Scripts -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>
  <script>
    AOS.init({ duration: 1000, once: true });
  </script>
</body>
</html>
