<?php include 'includes/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Zed Car Wash Management System</title>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <!-- FontAwesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <!-- AOS CSS -->
  <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet" />

  <style>
    body {
      font-family: 'Inter', sans-serif;
      background: #000;
      color: #fff;
      min-height: 100vh;
      overflow-x: hidden;
      display: flex;
      flex-direction: column;
    }

    body::before {
      content: "";
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 200%;
      background: white;
      background-size: cover;
      animation: scrollBg 60s linear infinite;
      z-index: -1;
      opacity: 0.6;
    }

    @keyframes scrollBg {
      0% { transform: translateY(0); }
      100% { transform: translateY(-50%); }
    }

    header {
      background: rgba(255, 255, 255, 0.95);
      padding: 1rem 2rem;
      position: sticky;
      top: 0;
      z-index: 1050;
      box-shadow: 0 2px 12px rgba(0, 0, 0, 0.15);
    }

    .navbar-brand {
      color: #003366;
      font-weight: 700;
      font-size: 1.75rem;
      display: flex;
      align-items: center;
      gap: 10px;
      text-decoration: none;
    }

    .navbar-brand img {
      height: 48px;
      width: 48px;
      object-fit: cover;
      border-radius: 50%;
      border: 2px solid #003366;
    }

    .navbar-nav .nav-link {
      color: #003366 !important;
      font-weight: 600;
      transition: background-color 0.3s, color 0.3s;
      border-radius: 0.375rem;
    }

    .navbar-nav .nav-link:hover,
    .navbar-nav .nav-link.active {
      background-color: teal !important;
      color: #fff !important;
    }

    .carousel-item img {
      max-height: 450px;
      object-fit: cover;
      border-radius: 1rem;
      box-shadow: 0 10px 30px rgba(0,0,0,0.6);
    }

    main {
      flex-grow: 1;
      width: 100%;
      padding: 3rem 1rem;
      position: relative;
      z-index: 1;
    }

    .hero {
      background: rgba(0, 0, 0, 0.7);
      padding: 3rem;
      border-radius: 1rem;
      box-shadow: 0 16px 32px rgba(0, 0, 0, 0.7);
      color: #eee;
    }

    .hero h2 {
      font-weight: 800;
      color: #ffcc00;
      line-height: 1.1;
    }

    .btn-yellow {
      background-color: #ffcc00;
      color: #003366;
      font-weight: 700;
      padding: 0.75rem 2rem;
      border-radius: 1rem;
      box-shadow: 0 6px 12px rgba(255, 204, 0, 0.5);
      transition: background-color 0.3s;
      margin-right: 0.5rem;
      display: inline-block;
    }

    .btn-yellow:hover {
      background-color: #b3a300;
      color: #fff;
    }

    .service-card {
      background: #f0f6f6;
      border-radius: 1rem;
      padding: 2rem 1.5rem;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
      text-align: center;
      transition: transform 0.3s;
      color: #004d4d;
    }

    .service-card:hover {
      transform: translateY(-8px);
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
    }

    .ad-banner {
      margin-top: 2.5rem;
      border-radius: 1.25rem;
      overflow: hidden;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.6);
      cursor: pointer;
      transition: transform 0.3s;
      max-height: 350px;
    }

    .ad-banner:hover {
      transform: scale(1.02);
    }

    footer {
      background-color: rgba(0, 38, 51, 0.9);
      color: #ddd;
      text-align: center;
      padding: 1.25rem 1rem;
      font-size: 1rem;
      margin-top: auto;
    }

    /* Floating CTA Buttons */
    .floating-cta {
      position: fixed;
      bottom: 25px;
      right: 25px;
      z-index: 999;
      display: flex;
      flex-direction: column;
      gap: 15px;
    }

    .floating-cta a {
      background-color: #25d366;
      color: white;
      font-size: 1.25rem;
      padding: 0.6rem 1rem;
      border-radius: 50px;
      display: flex;
      align-items: center;
      gap: 10px;
      text-decoration: none;
      box-shadow: 0 4px 12px rgba(0,0,0,0.25);
      transition: 0.3s;
    }

    .floating-cta a.instagram {
      background-color: #e4405f;
    }

    .floating-cta a:hover {
      transform: scale(1.05);
    }
  </style>
</head>

<body>

  <header>
    <nav class="navbar navbar-expand-lg navbar-light bg-white">
      <div class="container">
        <a class="navbar-brand" href="index.php">
          <img src="assets/logo.png" alt="Zed Logo">
          Zed Car Wash <i class="fa-solid fa-car"></i>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item"><a class="nav-link active" href="index.php"><i class="fas fa-home me-1"></i>Home</a></li>
            <li class="nav-item"><a class="nav-link" href="user/user_dashboard.php"><i class="fas fa-user me-1"></i>Users</a></li>
            <li class="nav-item"><a class="nav-link" href="admin/admin_dashboard.php"><i class="fas fa-user-shield me-1"></i>Admin</a></li>
            <li class="nav-item"><a class="nav-link" href="about.php"><i class="fas fa-info-circle me-1"></i>About</a></li>
            <li class="nav-item"><a class="nav-link" href="services.php"><i class="fas fa-cogs me-1"></i>Services</a></li>
            <li class="nav-item"><a class="nav-link" href="contact.php"><i class="fas fa-envelope me-1"></i>Contact</a></li>
          </ul>
        </div>
      </div>
    </nav>
  </header>

  <main class="container">
    <section class="hero row align-items-center" data-aos="fade-up">
      <div class="col-lg-6 mb-4 mb-lg-0">
        <h2>Clean Cars, Happy Riders.</h2>
        <p>Professional car wash and detailing with unmatched quality. Drive clean and shine bright.</p>
        <a href="services.php" class="btn btn-yellow">
          <i class="fa-solid fa-spray-can-sparkles me-2"></i>Explore Services
        </a>
        <a href="user/register.php" class="btn btn-yellow">
          <i class="fa-solid fa-user-plus me-2"></i>Create Account
        </a>
      </div>
      <div class="col-lg-6 text-center">
        <img src="assets/zedd.jpg" alt="Zed Car Wash" class="img-fluid rounded shadow-lg" />
      </div>
    </section>

    <section class="services row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4 mt-5" data-aos="fade-up" data-aos-delay="300">
      <div class="col">
        <div class="service-card">
          <h3><i class="fa-solid fa-shower me-2 text-primary"></i>Exterior Wash</h3>
          <p>Quick & spotless exterior car cleaning for a fresh look.</p>
        </div>
      </div>
      <div class="col">
        <div class="service-card">
          <h3><i class="fa-solid fa-pump-soap me-2 text-primary"></i>Interior Detailing</h3>
          <p>Deep cleaning and vacuuming to freshen up your car’s interior.</p>
        </div>
      </div>
      <div class="col">
        <div class="service-card">
          <h3><i class="fa-solid fa-snowflake me-2 text-primary"></i>Engine Wash</h3>
          <p>Careful engine cleaning without damage to components.</p>
        </div>
      </div>
      <div class="col">
        <div class="service-card">
          <h3><i class="fa-solid fa-star me-2 text-primary"></i>Premium Wax</h3>
          <p>Protective wax coating for a long-lasting shiny finish.</p>
        </div>
      </div>
    </section>

    <section class="row mt-5 gx-4">
      <div class="col-md-6 mb-4 mb-md-0" data-aos="zoom-in" data-aos-delay="600">
        <div class="ad-banner">
          <img src="assets/zed.jpg" alt="Promo Offer 1" class="img-fluid rounded" />
        </div>
      </div>
      <div class="col-md-6" data-aos="zoom-in" data-aos-delay="700">
        <div class="ad-banner">
          <img src="assets/zed2.jpg" alt="Promo Offer 2" class="img-fluid rounded" />
        </div>
      </div>
    </section>
  </main>

  <footer>
    <p>&copy; 2025 Zed Group of Companies</p>
  </footer>

  <!-- JS Scripts -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
  <script>
    AOS.init({ once: true, easing: 'ease-in-out' });
  </script>
</body>
</html>
