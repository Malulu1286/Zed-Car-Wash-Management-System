<?php include 'includes/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>About Us - Zed Car Wash</title>

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <!-- AOS CSS -->
  <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Inter', sans-serif;
      background: #f5f9ff;
      color: #333;
    }

    .navbar {
      background: #ffffff;
      box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }

    .navbar-brand {
      color: #00bfff !important;
      font-weight: bold;
    }

    .nav-link {
      color: #00bfff !important;
      font-weight: 600;
    }

    .nav-link:hover {
      color: #007acc !important;
    }

    .container-custom {
      background: #ffffff;
      border-radius: 16px;
      box-shadow: 0 12px 30px rgba(0,191,255,0.1);
      padding: 40px;
      margin-top: 100px;
    }

    h2, h3 {
      color: #00bfff;
    }

    p {
      font-size: 1.1rem;
      line-height: 1.7;
    }

    .service-card {
      background: #f1faff;
      padding: 20px;
      margin-bottom: 30px;
      border-radius: 12px;
      border-left: 5px solid #00bfff;
    }

    ul li {
      padding: 15px;
      background-color: #f9f9f9;
      margin-bottom: 10px;
      border-radius: 8px;
      color: #333;
    }

    footer {
      text-align: center;
      padding: 20px 0;
      background-color: #eaf6ff;
      color: #555;
      margin-top: 60px;
    }
  </style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-light fixed-top px-4">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><i class="fas fa-car"></i> Zed Car Wash</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="index.php"><i class="fas fa-home me-1"></i>Home</a></li>
        <li class="nav-item"><a class="nav-link" href="services.php"><i class="fas fa-list me-1"></i>Services</a></li>
        <li class="nav-item"><a class="nav-link" href="user/user_dashboard.php"><i class="fas fa-user me-1"></i>User</a></li>
        <li class="nav-item"><a class="nav-link" href="admin/admin_dashboard.php"><i class="fas fa-user-shield me-1"></i>Admin</a></li>
        <li class="nav-item"><a class="nav-link" href="contact.php"><i class="fas fa-envelope me-1"></i>Contact</a></li>
        <li class="nav-item"><a class="nav-link active" href="about.php"><i class="fas fa-info-circle me-1"></i>About</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- MAIN CONTAINER -->
<div class="container container-custom" data-aos="fade-up">
  <h2 class="mb-4">About Us</h2>
  <p>Welcome to <strong>Zed Car Wash</strong> – where your car gets the care it deserves!</p>
  <p>Located inside the Institute of Accountancy Arusha (IAA), we proudly serve students, staff, and the surrounding community with high-quality car wash services. Whether you need a quick rinse, a deep clean, or full detailing, we’re here to make your ride look its best — and do it with a smile.</p>
  <p>Our team is passionate about cleanliness and customer satisfaction. We use eco-friendly cleaning products and modern techniques to ensure a spotless shine while protecting the environment.</p>

  <div class="service-card" data-aos="fade-right">
    <h3><i class="fas fa-bullseye me-2"></i>Our Mission</h3>
    <p>To provide affordable, professional, and eco-conscious car care services in a friendly and efficient manner — right at your convenience.</p>
  </div>

  <div class="service-card" data-aos="fade-left">
    <h3><i class="fas fa-clock me-2"></i>Operating Hours</h3>
    <p><strong>Monday to Friday:</strong> 8:00 AM – 6:00 PM</p>
    <p><strong>Sunday:</strong> 10:00 AM – 4:00 PM</p>
  </div>

  <div class="service-card" data-aos="fade-up">
    <h3><i class="fas fa-quote-left me-2"></i>A Message from the CEO</h3>
    <p>"Zed Car Wash was started with one simple goal: to make top-notch car care accessible and affordable for our local community, especially within the campus. We're committed to excellence and customer satisfaction. Thank you for trusting us with your vehicle!"</p>
    <p><strong>— Zed Malulu, CEO</strong></p>
  </div>

  <h3 class="mt-4"><i class="fas fa-star me-2"></i>Our Popular Services</h3>
  <ul>
    <?php
      $stmt = $dbh->prepare("SELECT service_name, description FROM services LIMIT 10");
      $stmt->execute();
      $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
      foreach ($results as $row) {
          echo "<li><strong>" . htmlspecialchars($row['service_name']) . "</strong>: " . htmlspecialchars($row['description']) . "</li>";
      }
    ?>
  </ul>
</div>

<!-- FOOTER -->
<footer>
  <p>&copy; 2025 Zed Group of Companies</p>
</footer>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init();
</script>

</body>
</html>
