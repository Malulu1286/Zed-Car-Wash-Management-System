<?php
include 'includes/config.php';

// Hardcoded features per service name
$serviceFeatures = [
  "Motorcycles Wash" => [
    "Gentle hand wash and rinse",
    "Engine and undercarriage degreasing",
    "Tire and chain cleaning",
    "Quick dry and polish"
  ],
  "Basic Wash" => [
    "Exterior hand wash",
    "Wheel cleaning",
    "Tire shine",
    "Exterior dry with microfiber towels"
  ],
  "Full Wash" => [
    "Exterior wash & wax",
    "Interior vacuuming",
    "Dashboard & panel wipe-down",
    "Window cleaning (in & out)"
  ],
  "Premium Wash" => [
    "Complete full wash",
    "Hand wax & polish",
    "Tire blackening & engine wash",
    "Interior deodorizing"
  ],
  "Scania" => [
    "Foam wash with high-pressure rinse",
    "Undercarriage and wheels blast",
    "Interior cleaning if accessible",
    "Cabin air freshening"
  ]
];

// Get service name from URL
$serviceName = urldecode($_GET['service'] ?? '');

if (!$serviceName) {
    echo "<script>alert('No service specified.'); window.location='../services.php';</script>";
    exit;
}

// Fetch service data from DB
try {
    $stmt = $dbh->prepare("SELECT service_name, description, price FROM services WHERE service_name = ?");
    $stmt->execute([$serviceName]);
    $service = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$service) {
        echo "<script>alert('Service not found.'); window.location='../services.php';</script>";
        exit;
    }

    // Fetch features array if exists, else empty
    $features = $serviceFeatures[$service['service_name']] ?? [];

} catch (PDOException $e) {
    echo "<p>Error fetching service: " . htmlspecialchars($e->getMessage()) . "</p>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?php echo htmlspecialchars($service['service_name']); ?> - Zed Car Wash</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link href="https://unpkg.com/aos@2.3.4/dist/aos.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Inter', sans-serif;
      background-color: #fefefe;
      color: #333;
      padding-bottom: 60px;
    }
    .container {
      margin-top: 60px;
    }
    .card {
      border: none;
      border-radius: 15px;
      box-shadow: 0 12px 24px rgba(0, 191, 255, 0.1);
    }
    .price-badge {
      background-color: #00bfff;
      color: #fff;
      padding: 8px 20px;
      border-radius: 25px;
      font-weight: 600;
      font-size: 1rem;
      display: inline-block;
      margin-top: 15px;
    }
    .btn-back {
      background-color: #007bff;
      color: #fff;
    }
    .btn-back:hover {
      background-color: #0056b3;
    }
  </style>
</head>
<body>
  <div class="container" data-aos="fade-up">
    <a href="services.php" class="btn btn-back mb-4"><i class="fas fa-arrow-left"></i> Back to Services</a>
    <div class="card p-5">
      <h2 class="text-primary mb-3"><i class="fas fa-car"></i> <?php echo htmlspecialchars($service['service_name']); ?></h2>
      <p class="lead"><?php echo nl2br(htmlspecialchars($service['description'])); ?></p>

      <?php if ($features): ?>
        <h5 class="mt-4">Features:</h5>
        <ul class="list-group list-group-flush mb-4">
          <?php foreach ($features as $feature): ?>
            <li class="list-group-item"><i class="fas fa-check text-success me-2"></i> <?php echo htmlspecialchars($feature); ?></li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>

      <span class="price-badge">Price: <?php echo number_format($service['price'], 2); ?> TZS</span>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>
  <script>
    AOS.init({ duration: 1000 });
  </script>
</body>
</html>
