<?php
session_start();
include '../includes/config.php'; // This file should create $dbh PDO connection

if (!isset($_SESSION['user_id'])) {
    header("Location: user_login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user details by customer_id
$stmt = $dbh->prepare("SELECT customer_name, customer_phone, email FROM customers WHERE customer_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    die("User not found.");
}

// Services list and their prices
$services = [
    "Motorcycles Wash" => 5000,
    "Basic Wash" => 15000,
    "Full Wash" => 20000,
    "Premium Wash" => 30000,
    "Scania" => 30000
];

$service = $_GET['service'] ?? '';

if (!array_key_exists($service, $services)) {
    die("Invalid service selected.");
}

$price = $services[$service];
$success = false;
$control_number = '';
$appointment_date = '';
$payment_method = 'Control Number';
$status = 'Pending';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customer_name  = trim($_POST['customer_name']);
    $customer_phone = trim($_POST['customer_phone']);
    $email         = trim($_POST['email']);
    $appointment_date = trim($_POST['appointment_date']);
    $control_number = "ZED" . rand(100000, 999999);

    // Insert payment record
    $stmt = $dbh->prepare("INSERT INTO payments (service_name, amount, customer_name, phone, email, control_number, status) VALUES (?, ?, ?, ?, ?, ?, 'Pending')");
    $stmt->execute([
        $service,
        $price,
        $customer_name,
        $customer_phone,
        $email,
        $control_number
    ]);

    // Get service_id from services table
    $stmtService = $dbh->prepare("SELECT service_id FROM services WHERE service_name = ?");
    $stmtService->execute([$service]);
    $serviceData = $stmtService->fetch(PDO::FETCH_ASSOC);

    if ($serviceData) {
        $service_id = $serviceData['service_id'];

        // Insert booking record
        $stmtBooking = $dbh->prepare("INSERT INTO bookings (customer_id, service_id, appointment_date, payment_method, status) VALUES (?, ?, ?, ?, ?)");
        $stmtBooking->execute([
            $user_id,
            $service_id,
            $appointment_date,
            $payment_method,
            $status
        ]);

        $success = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Payment - Zed Car Wash</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet" />
  <style>
    body {
      font-family: 'Inter', sans-serif;
      background-color: #f8f9fa;
    }
    .container {
      max-width: 600px;
      margin: 60px auto;
      padding: 30px;
      background: white;
      border-radius: 15px;
      box-shadow: 0 4px 16px rgba(0,0,0,0.1);
    }
    h2 {
      color: #00bfff;
      font-weight: 700;
    }
    label {
      font-weight: 600;
      margin-top: 15px;
    }
    .btn-pay {
      background-color: #00bfff;
      color: white;
      font-weight: 600;
      margin-top: 20px;
    }
    .alert-success {
      margin-top: 20px;
    }
    .back-link {
      margin-top: 30px;
      text-align: center;
    }
    .back-link a {
      text-decoration: none;
      color: #00bfff;
      font-weight: 600;
    }
    .back-link a:hover {
      text-decoration: underline;
      color: #007acc;
    }
  </style>
</head>
<body>
<div class="container">
  <h2 class="mb-4"><i class="fas fa-money-bill-wave"></i> Confirm Payment</h2>
  <p><strong>Service:</strong> <?= htmlspecialchars($service) ?></p>
  <p><strong>Price:</strong> <?= number_format($price) ?> TZS</p>

  <?php if ($success): ?>
    <div class="alert alert-success">
      <strong>Success!</strong> Payment and booking recorded.<br>
      <strong>Control Number:</strong> <?= htmlspecialchars($control_number) ?><br>
      <span>Status: <span class="text-warning">Pending</span></span><br>
      <strong>Appointment:</strong> <?= htmlspecialchars($appointment_date) ?>
    </div>
  <?php else: ?>
    <form method="POST" novalidate>
      <label for="customer_name">Full Name:</label>
      <input type="text" id="customer_name" name="customer_name" class="form-control" required value="<?= htmlspecialchars($user['customer_name']) ?>">

      <label for="customer_phone">Phone Number:</label>
      <input type="text" id="customer_phone" name="customer_phone" class="form-control" required value="<?= htmlspecialchars($user['customer_phone']) ?>">

      <label for="email">Email:</label>
      <input type="email" id="email" name="email" class="form-control" required value="<?= htmlspecialchars($user['email']) ?>">

      <label for="appointment_date">Appointment Date:</label>
      <input type="date" id="appointment_date" name="appointment_date" class="form-control" required min="<?= date('Y-m-d') ?>">

      <button type="submit" class="btn btn-pay w-100">Confirm & Book</button>
    </form>
  <?php endif; ?>

  <div class="back-link">
    <a href="bookings.php"><i class="fas fa-arrow-left"></i> Back to My Bookings</a>
  </div>
</div>
</body>
</html>
