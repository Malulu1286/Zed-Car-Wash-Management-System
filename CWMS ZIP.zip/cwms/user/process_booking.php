<?php
session_start();
include '../includes/config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: user_login.php");
    exit();
}

// Setup PHPMailer
$phpmailer_path = realpath(__DIR__ . '/../includes/PHPMailer/PHPMailer/src/');
if (!file_exists($phpmailer_path . '/PHPMailer.php')) {
    die("PHPMailer.php not found at: $phpmailer_path");
}

require_once $phpmailer_path . '/PHPMailer.php';
require_once $phpmailer_path . '/Exception.php';
require_once $phpmailer_path . '/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function sendConfirmationEmail($to, $name, $service_name, $appointment_date) {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // Gmail SMTP
        $mail->SMTPAuth = true;
        $mail->Username = 'your_email@gmail.com';         // ✅ Replace
        $mail->Password = 'your_app_password';            // ✅ Replace with App Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('your_email@gmail.com', 'Zed Car Wash');
        $mail->addAddress($to, $name);
        $mail->isHTML(true);
        $mail->Subject = 'Zed Car Wash Booking Confirmation';
        $mail->Body = "
            <h2>Booking Confirmed</h2>
            <p>Dear <strong>$name</strong>,</p>
            <p>Your booking for <strong>$service_name</strong> on <strong>$appointment_date</strong> is confirmed.</p>
            <p>Thank you for choosing Zed Car Wash!</p>
        ";
        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Email Error: " . $mail->ErrorInfo);
        return false;
    }
}

// Redirect with 10-second countdown
function redirectWithCountdown() {
    return "
        <p id='countdown'>Redirecting in <strong>10</strong> seconds...</p>
        <div class='spinner-border text-primary mt-3' role='status'></div>
        <script>
            let count = 10;
            const el = document.getElementById('countdown');
            const timer = setInterval(() => {
                count--;
                el.innerHTML = 'Redirecting in <strong>' + count + '</strong> seconds...';
                if (count <= 0) clearInterval(timer);
            }, 1000);
            setTimeout(() => window.location.href = 'user_dashboard.php', 10000);
        </script>";
}

// Process form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['customer_name'] ?? '');
    $phone = trim($_POST['customer_phone'] ?? '');
    $email = trim($_POST['customer_email'] ?? '');
    $service_id = $_POST['service_id'] ?? '';
    $appointment_date = $_POST['appointment_date'] ?? '';
    $payment_method = $_POST['payment_method'] ?? '';
    $mobile_number = $_POST['mobile_number'] ?? null;
    $card_number = $_POST['card_number'] ?? null;
    $card_expiry = $_POST['card_expiry'] ?? null;

    $customer_id = $_SESSION['user_id'];

    if (!$name || !$phone || !$email || !$service_id || !$appointment_date || !$payment_method) {
        exit("<h3 class='text-danger'>Missing required fields</h3>");
    }

    // Fetch service name
    $stmt = $dbh->prepare("SELECT service_name FROM services WHERE service_id = ?");
    $stmt->execute([$service_id]);
    $service = $stmt->fetch(PDO::FETCH_ASSOC);
    $service_name = $service ? $service['service_name'] : 'Selected Service';

    $status = 'Confirmed';
    $card_last4 = $card_number ? substr(preg_replace("/\D/", "", $card_number), -4) : null;

    // Simulate payment logic (real gateway needed)
    if ($payment_method === 'Cash') {
        // No card or mobile info needed
    } elseif ($payment_method === 'Mobile Payment') {
        sleep(3); // Simulate delay
    } elseif ($payment_method === 'Card') {
        sleep(3); // Simulate delay
    } else {
        exit("<h3 class='text-danger'>Invalid payment method</h3>");
    }

    // Insert booking
    $stmt = $dbh->prepare("INSERT INTO bookings 
        (customer_id, service_id, appointment_date, payment_method, mobile_number, card_number_last4, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $customer_id, $service_id, $appointment_date, $payment_method,
        $mobile_number, $card_last4, $status
    ]);

    $email_sent = sendConfirmationEmail($email, $name, $service_name, $appointment_date);

    // Output result
    echo "<!DOCTYPE html>
    <html><head>
      <title>Booking Confirmation</title>
      <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css'>
      <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css'>
    </head><body style='background:#f2f7fc;padding:40px;'>
    <div class='container text-center'>
      <div class='p-5 bg-white rounded shadow' style='max-width:600px;margin:auto;'>
        <div class='icon-success mb-3'><i class='fas fa-check-circle fa-3x text-success'></i></div>
        <h2>Booking Confirmed</h2>
        <p>Thank you, <strong>$name</strong>. Your booking for <strong>$service_name</strong> has been received.</p>" .
        ($email_sent ? "<p>Email sent to <strong>$email</strong>.</p>" : "<p class='text-danger'>Email sending failed.</p>") .
        redirectWithCountdown() . "
      </div>
    </div>
    </body></html>";
}
?>
