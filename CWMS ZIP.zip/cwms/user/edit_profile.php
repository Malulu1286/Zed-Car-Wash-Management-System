<?php
session_start();

if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_name'])) {
    header("Location: user_login.html");
    exit();
}

include '../includes/config.php';

$user_id = $_SESSION['user_id'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['customer_name'] ?? '';
    $phone = $_POST['customer_phone'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (empty($name) || empty($phone)) {
        $error = "Name and phone number are required.";
    } elseif (!empty($password) && $password !== $confirm) {
        $error = "Passwords do not match.";
    } else {
        if (!empty($password)) {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $dbh->prepare("UPDATE customers SET customer_name = ?, customer_phone = ?, password = ? WHERE customer_id = ?");
            $stmt->execute([$name, $phone, $hashed_password, $user_id]);
        } else {
            $stmt = $dbh->prepare("UPDATE customers SET customer_name = ?, customer_phone = ? WHERE customer_id = ?");
            $stmt->execute([$name, $phone, $user_id]);
        }

        $_SESSION['user_name'] = $name;
        $success = "Profile updated successfully.";
    }
}

// Load user info
$stmt = $dbh->prepare("SELECT * FROM customers WHERE customer_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    die("Error: User not found.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Edit Profile - Zed Car Wash</title>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <!-- FontAwesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet" />
  <!-- AOS -->
  <link href="https://unpkg.com/aos@2.3.4/dist/aos.css" rel="stylesheet" />

  <style>
    /* Sidebar styles */
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Poppins', sans-serif;
      color: #333;
      background: #fff;
      min-height: 100vh;
      overflow-x: hidden;
    }
    .sidebar {
      width: 260px;
      background-color: #f8f9fa;
      color: #000;
      display: flex;
      flex-direction: column;
      padding: 40px 20px;
      position: fixed;
      top: 0; bottom: 0;
      z-index: 1;
      transition: transform 0.3s ease-in-out;
      border-right: 1px solid #ddd;
    }
    .sidebar.collapsed { transform: translateX(-100%); }
    .toggle-btn {
      position: fixed;
      top: 20px; left: 270px;
      z-index: 2;
      background-color: rgba(0, 0, 0, 0.05);
      border: none;
      color: #000;
      padding: 10px 14px;
      font-size: 18px;
      cursor: pointer;
      border-radius: 6px;
      transition: left 0.3s ease-in-out;
    }
    .sidebar.collapsed ~ .toggle-btn { left: 10px; }
    .sidebar h2 {
      text-align: center;
      font-size: 22px;
      margin-bottom: 30px;
      font-weight: 600;
      color: #00bfff;
    }
    .sidebar a {
      text-decoration: none;
      color: #333;
      padding: 12px 18px;
      border-radius: 6px;
      margin-bottom: 14px;
      font-size: 15px;
      transition: background 0.3s;
    }
    .sidebar a:hover {
      background-color: #e7f5ff;
      color: #007bff;
    }
    .sidebar a.active {
      background-color: #e7f5ff;
      color: #007bff;
      font-weight: 600;
    }

    /* Main content */
    .main-content {
      margin-left: 260px;
      padding: 50px;
      background-color: rgba(255,255,255,0.95);
      min-height: 100vh;
      transition: margin-left 0.3s ease-in-out;
    }
    .main-content.collapsed { margin-left: 0; padding: 30px 20px; }

    /* Container for the form */
    .container-box {
      max-width: 600px;
      margin: auto;
      background: #fff;
      padding: 40px 30px;
      border-radius: 16px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.1);
    }

    h2.container-title {
      text-align: center;
      color: #00bfff;
      font-weight: 700;
      margin-bottom: 30px;
    }

    label {
      margin-bottom: 6px;
      font-weight: 600;
    }

    input[type="text"],
    input[type="password"] {
      width: 100%;
      padding: 12px;
      margin-bottom: 20px;
      border: 1px solid #ccc;
      border-radius: 10px;
      font-size: 16px;
      transition: border-color 0.3s ease;
    }

    input:focus {
      border-color: #00bfff;
      outline: none;
      background-color: #f1f9ff;
    }

    button {
      width: 100%;
      padding: 14px;
      background-color: #00bfff;
      border: none;
      color: #fff;
      font-weight: 600;
      font-size: 16px;
      border-radius: 12px;
      transition: background-color 0.3s;
    }

    button:hover {
      background-color: #0090cc;
    }

    .back-link {
      text-align: center;
      margin-top: 20px;
    }

    .back-link a {
      text-decoration: none;
      color: #00bfff;
      font-weight: 500;
      font-size: 1rem;
      transition: color 0.3s ease;
    }

    .back-link a:hover {
      color: #007acc;
    }

    p.success, p.error {
      text-align: center;
      font-weight: 500;
      margin-bottom: 20px;
    }

    p.success {
      color: #28a745;
    }

    p.error {
      color: #dc3545;
    }

    footer {
      text-align: center;
      padding: 18px 0;
      margin-top: 50px;
      font-size: 0.95rem;
      color: #666;
      margin-left: 260px;
      transition: margin-left 0.3s ease-in-out;
    }
    footer.collapsed {
      margin-left: 0;
    }

    @media (max-width: 640px) {
      .container-box {
        margin: 40px 20px;
        padding: 30px 20px;
      }

      .main-content {
        margin-left: 0;
        padding: 30px 20px;
      }

      footer {
        margin-left: 0;
      }

      .sidebar {
        transform: translateX(-100%);
      }

      .toggle-btn {
        left: 10px !important;
      }
    }
  </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar" id="sidebar">
  <h2><i class="fas fa-gauge"></i> User Dashboard</h2>
  <a href="../index.php"><i class="fas fa-home me-2"></i>Home</a>
  <a href="bookings.php"><i class="fas fa-calendar-check me-2"></i>Book a Service</a>
  <a href="user_bookings.php"><i class="fas fa-list-check me-2"></i>My Bookings</a>
  <a href="edit_profile.php" class="active"><i class="fas fa-user-edit me-2"></i>Edit Profile</a>
  <a href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
</div>

<button class="toggle-btn" onclick="toggleSidebar()" id="toggleBtn"><i class="fas fa-bars"></i></button>

<!-- Main content -->
<div class="main-content" id="mainContent" data-aos="fade-up" data-aos-delay="200" data-aos-duration="1000">

  <div class="container-box shadow-sm">
    <h2 class="container-title"><i class="fas fa-user-edit"></i> Edit Profile</h2>

    <?php if (!empty($error)) : ?>
      <p class="error"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <?php if (!empty($success)) : ?>
      <p class="success"><?= htmlspecialchars($success) ?></p>
    <?php endif; ?>

    <form method="POST" novalidate>
      <div class="mb-3">
        <label for="customer_name" class="form-label">Full Name</label>
        <input type="text" name="customer_name" id="customer_name" class="form-control" value="<?= htmlspecialchars($user['customer_name']) ?>" required />
      </div>

      <div class="mb-3">
        <label for="customer_phone" class="form-label">Phone Number</label>
        <input type="text" name="customer_phone" id="customer_phone" class="form-control" value="<?= htmlspecialchars($user['customer_phone']) ?>" required />
      </div>

      <div class="mb-3">
        <label for="password" class="form-label">New Password <small class="text-muted">(leave blank to keep current)</small></label>
        <input type="password" name="password" id="password" class="form-control" autocomplete="new-password" />
      </div>

      <div class="mb-3">
        <label for="confirm_password" class="form-label">Confirm New Password</label>
        <input type="password" name="confirm_password" id="confirm_password" class="form-control" autocomplete="new-password" />
      </div>

      <button type="submit" class="btn btn-primary">
        <i class="fas fa-save"></i> Update Profile
      </button>

      <div class="back-link mt-3">
        <a href="user_dashboard.php"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
      </div>
    </form>
  </div>

</div>

<footer id="footer">
  <p>&copy; 2025 Zed Group of Companies</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init({ duration: 1000, once: true });

  function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('collapsed');
    document.getElementById('mainContent').classList.toggle('collapsed');
    document.getElementById('footer').classList.toggle('collapsed');
    document.getElementById('toggleBtn').classList.toggle('collapsed');
  }
</script>

</body>
</html>
