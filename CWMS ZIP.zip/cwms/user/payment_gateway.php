session_start();
include '../includes/config.php';

$booking = $_SESSION['booking_data'] ?? null;

if (!$booking) {
    die("No booking session found.");
}

// 1. Start payment request via API (mock below)
// sendSTKPush($booking['customer_phone'], $amount); // Real code here

echo "Waiting for payment confirmation...";

// 2. Simulate confirmation (replace with real callback handler)
sleep(5); // simulate waiting

// 3. Insert into bookings after payment success
$stmt = $dbh->prepare("INSERT INTO bookings (customer_id, service_id, appointment_date, payment_method, status)
                      VALUES (?, ?, ?, ?, 'Booked')");
$stmt->execute([
    $booking['customer_id'],
    $booking['service_id'],
    $booking['appointment_date'],
    $booking['payment_method']
]);

unset($_SESSION['booking_data']);

header("Location: booking_success.php?success=1");
exit;
