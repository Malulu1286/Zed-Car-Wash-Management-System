<?php
session_start();
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_name'])) {
    header("Location: login.php");
    exit();
}

include '../includes/config.php';

$customer_id = $_SESSION['user_id'];

$sql = "SELECT b.booking_id, b.appointment_date, b.status, b.payment_method, 
               b.tx_ref, b.mobile_number, b.card_number_last4, b.created_at, 
               s.service_name, s.price
        FROM bookings b
        JOIN services s ON b.service_id = s.service_id
        WHERE b.customer_id = ?
        ORDER BY b.created_at DESC";

$stmt = $dbh->prepare($sql);
$stmt->execute([$customer_id]);
$bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>My Bookings - Zed Car Wash</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />
  <link href="https://unpkg.com/aos@2.3.4/dist/aos.css" rel="stylesheet" />

  <style>
    /* Sidebar styles (same as your dashboard) */
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Poppins', sans-serif;
      color: #333;
      background: #fff;
      background-size: cover;
      overflow-x: hidden;
      min-height: 100vh;
    }
    .sidebar {
      width: 260px;
      background-color: #f8f9fa;
      color: #000;
      display: flex;
      flex-direction: column;
      padding: 40px 20px;
      position: fixed;
      top: 0; bottom: 0;
      z-index: 1;
      transition: transform 0.3s ease-in-out;
      border-right: 1px solid #ddd;
    }
    .sidebar.collapsed { transform: translateX(-100%); }
    .toggle-btn {
      position: fixed;
      top: 20px; left: 270px;
      z-index: 2;
      background-color: rgba(0, 0, 0, 0.05);
      border: none;
      color: #000;
      padding: 10px 14px;
      font-size: 18px;
      cursor: pointer;
      border-radius: 6px;
      transition: left 0.3s ease-in-out;
    }
    .sidebar.collapsed ~ .toggle-btn { left: 10px; }
    .sidebar h2 {
      text-align: center;
      font-size: 22px;
      margin-bottom: 30px;
      font-weight: 600;
      color: #00bfff;
    }
    .sidebar a {
      text-decoration: none;
      color: #333;
      padding: 12px 18px;
      border-radius: 6px;
      margin-bottom: 14px;
      font-size: 15px;
      transition: background 0.3s;
    }
    .sidebar a:hover {
      background-color: #e7f5ff;
      color: #007bff;
    }
    .sidebar a.active {
      background-color: #e7f5ff;
      color: #007bff;
      font-weight: 600;
    }

    /* Main content */
    .main-content {
      margin-left: 260px;
      padding: 50px;
      background-color: rgba(255,255,255,0.95);
      min-height: 100vh;
      transition: margin-left 0.3s ease-in-out;
    }
    .main-content.collapsed { margin-left: 0; padding: 30px 20px; }

    /* Container for bookings */
    .container-box {
      max-width: 1100px;
      margin: auto;
      background: #fff;
      border-radius: 16px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.08);
      padding: 40px 30px;
    }

    h2 {
      text-align: center;
      color: #00bfff;
      font-weight: 700;
      margin-bottom: 30px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    th, td {
      padding: 12px 15px;
      border-bottom: 1px solid #e0e0e0;
      text-align: left;
    }

    th {
      background-color: #f1f9ff;
      color: #007acc;
      font-weight: 600;
    }

    tr:nth-child(even) {
      background-color: #fafafa;
    }

    .status-Confirmed { color: #28a745; font-weight: bold; }
    .status-Pending { color: #ffc107; font-weight: bold; }
    .status-Cancelled { color: #dc3545; font-weight: bold; }

    .btn-danger {
      font-size: 0.875rem;
      padding: 6px 12px;
      border-radius: 6px;
    }

    .back-link {
      text-align: center;
      margin-top: 30px;
    }

    .back-link a {
      text-decoration: none;
      font-weight: 600;
      color: #00bfff;
    }

    .back-link a:hover {
      color: #007acc;
    }

    .no-bookings {
      text-align: center;
      font-size: 1.2rem;
      margin-top: 20px;
    }

    footer {
      text-align: center;
      padding: 15px 0;
      background-color: #f1f1f1;
      color: #555;
      font-size: 0.95rem;
      margin-top: 40px;
      margin-left: 260px;
      transition: margin-left 0.3s ease-in-out;
    }
    footer.collapsed {
      margin-left: 0;
    }

    @media (max-width: 768px) {
      .container-box {
        padding: 25px 15px;
      }

      table {
        font-size: 0.9rem;
      }

      th, td {
        padding: 10px 8px;
      }

      .btn-danger {
        padding: 4px 10px;
      }

      .main-content {
        margin-left: 0;
        padding: 30px 20px;
      }

      footer {
        margin-left: 0;
      }

      .sidebar {
        transform: translateX(-100%);
      }

      .toggle-btn {
        left: 10px !important;
      }
    }
  </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar" id="sidebar">
  <h2><i class="fas fa-gauge"></i> User Dashboard</h2>
  <a href="../index.php"><i class="fas fa-home me-2"></i>Home</a>
  <a href="bookings.php"><i class="fas fa-calendar-check me-2"></i>Book a Service</a>
  <a href="user_bookings.php" class="active"><i class="fas fa-list-check me-2"></i>My Bookings</a>
  <a href="edit_profile.php"><i class="fas fa-user-edit me-2"></i>Edit Profile</a>
  <a href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
</div>

<button class="toggle-btn" onclick="toggleSidebar()" id="toggleBtn"><i class="fas fa-bars"></i></button>

<!-- Main content -->
<div class="main-content" id="mainContent" data-aos="fade-up" data-aos-delay="200" data-aos-duration="1000">

  <div class="container-box">
    <h2><i class="fas fa-calendar-alt"></i> My Bookings</h2>

    <?php if (count($bookings) === 0): ?>
      <p class="no-bookings">You have no bookings yet.</p>
    <?php else: ?>
      <div class="table-responsive">
        <table class="table table-striped">
          <thead>
          <tr>
            <th>Service</th>
            <th>Price (TZS)</th>
            <th>Appointment Date</th>
            <th>Payment</th>
            <th>Transaction Ref</th>
            <th>Mobile/Card Info</th>
            <th>Status</th>
            <th>Booked On</th>
            <th>Action</th>
          </tr>
          </thead>
          <tbody>
          <?php foreach ($bookings as $b): ?>
            <tr>
              <td><?= htmlspecialchars($b['service_name']) ?></td>
              <td><?= number_format($b['price']) ?></td>
              <td><?= date('d M Y, H:i', strtotime($b['appointment_date'])) ?></td>
              <td><?= htmlspecialchars($b['payment_method']) ?></td>
              <td><?= htmlspecialchars($b['tx_ref'] ?? '-') ?></td>
              <td>
                <?php 
                if ($b['payment_method'] === 'Mobile Payment' && $b['mobile_number']) {
                    echo htmlspecialchars($b['mobile_number']);
                } elseif ($b['payment_method'] === 'Card' && $b['card_number_last4']) {
                    echo '**** **** **** ' . htmlspecialchars($b['card_number_last4']);
                } else {
                    echo '-';
                }
                ?>
              </td>
              <td class="status-<?= htmlspecialchars($b['status']) ?>"><?= htmlspecialchars($b['status']) ?></td>
              <td><?= date('d M Y, H:i', strtotime($b['created_at'])) ?></td>
              <td>
                <form method="POST" action="delete_booking.php" onsubmit="return confirm('Are you sure you want to delete this booking?');">
                  <input type="hidden" name="booking_id" value="<?= $b['booking_id'] ?>">
                  <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>

    <div class="back-link">
      <a href="user_dashboard.php">← Back to Dashboard</a>
    </div>
  </div>

</div>

<footer id="footer">
  <p>&copy; 2025 Zed Group of Companies</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init({ duration: 1000, once: true });

  function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('collapsed');
    document.getElementById('mainContent').classList.toggle('collapsed');
    document.getElementById('footer').classList.toggle('collapsed');
    document.getElementById('toggleBtn').classList.toggle('collapsed');
  }
</script>

</body>
</html>
