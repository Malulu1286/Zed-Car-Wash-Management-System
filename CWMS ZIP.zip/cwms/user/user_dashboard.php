<?php  
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: user_login.php");
    exit();
}
include '../includes/config.php';

$customer_id = $_SESSION['user_id'];

try {
    $stmt = $dbh->prepare("SELECT customer_name FROM customers WHERE customer_id = ?");
    $stmt->execute([$customer_id]);
    $customer = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$customer) {
        session_destroy();
        header("Location: user_login.php");
        exit();
    }
    $customer_name = $customer['customer_name'];
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>User Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet" />
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Poppins', sans-serif;
      color: #333;
      background: #fff;
      background-size: cover;
      overflow-x: hidden;
      min-height: 100vh;
    }
    .sidebar {
      width: 260px;
      background-color: #f8f9fa;
      color: #000;
      display: flex;
      flex-direction: column;
      padding: 40px 20px;
      position: fixed;
      top: 0; bottom: 0;
      z-index: 1;
      transition: transform 0.3s ease-in-out;
      border-right: 1px solid #ddd;
    }
    .sidebar.collapsed { transform: translateX(-100%); }
    .toggle-btn {
      position: fixed;
      top: 20px; left: 270px;
      z-index: 2;
      background-color: rgba(0, 0, 0, 0.05);
      border: none;
      color: #000;
      padding: 10px 14px;
      font-size: 18px;
      cursor: pointer;
      border-radius: 6px;
      transition: left 0.3s ease-in-out;
    }
    .sidebar.collapsed ~ .toggle-btn { left: 10px; }
    .sidebar h2 {
      text-align: center;
      font-size: 22px;
      margin-bottom: 30px;
      font-weight: 600;
      color: #00bfff;
    }
    .sidebar a {
      text-decoration: none;
      color: #333;
      padding: 12px 18px;
      border-radius: 6px;
      margin-bottom: 14px;
      font-size: 15px;
      transition: background 0.3s;
    }
    .sidebar a:hover {
      background-color: #e7f5ff;
      color: #007bff;
    }
    .main-content {
      margin-left: 260px;
      padding: 50px;
      background-color: rgba(255,255,255,0.95);
      min-height: 100vh;
      transition: margin-left 0.3s ease-in-out;
    }
    .main-content.collapsed { margin-left: 0; }
    .main-content h1 {
      font-size: 26px;
      color: #222;
      margin-bottom: 30px;
    }
    .card-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
      gap: 24px;
    }
    .card {
      background: #ffffff;
      border: 1px solid #ddd;
      border-radius: 14px;
      padding: 24px;
      text-align: center;
      transition: transform 0.3s ease;
      box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
    }
    .card:hover {
      transform: translateY(-5px);
      background-color: #f1faff;
    }
    .card h3 { font-size: 18px; margin-bottom: 10px; color: #00bfff; }
    .card p { font-size: 14px; color: #555; }
    footer {
      position: fixed;
      bottom: 0; left: 260px; right: 0;
      background-color: #f1f1f1;
      color: #555;
      text-align: center;
      padding: 12px 0;
      font-size: 14px;
      transition: left 0.3s ease-in-out;
    }
    footer.collapsed { left: 0; }
    @media (max-width: 768px) {
      .main-content { margin-left: 0; padding: 30px 20px; }
      footer { left: 0; }
    }
  </style>
</head>
<body>

<div class="sidebar" id="sidebar">
  <h2><i class="fas fa-gauge"></i> User Dashboard</h2>
  <a href="../index.php"><i class="fas fa-home me-2"></i>Home</a>
  <a href="bookings.php"><i class="fas fa-calendar-check me-2"></i>Book a Service</a>
  <a href="user_bookings.php"><i class="fas fa-list-check me-2"></i>My Bookings</a>
  <a href="edit_profile.php"><i class="fas fa-user-edit me-2"></i>Edit Profile</a>
  <a href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
</div>

<button class="toggle-btn" onclick="toggleSidebar()" id="toggleBtn"><i class="fas fa-bars"></i></button>

<div class="main-content" id="mainContent" data-aos="fade-up" data-aos-delay="200" data-aos-duration="1000">
  <h1>Welcome, <?php echo htmlspecialchars($customer_name); ?>!</h1>
  <div class="card-grid">
    <a href="bookings.php" class="card text-decoration-none" data-aos="zoom-in" data-aos-delay="100">
      <h3><i class="fas fa-calendar-plus"></i> Book a Service</h3>
      <p>Schedule your next car wash</p>
    </a>
    <a href="edit_profile.php" class="card text-decoration-none" data-aos="zoom-in" data-aos-delay="200">
      <h3><i class="fas fa-user-edit"></i> Edit Profile</h3>
      <p>Update your personal info and settings</p>
    </a>
    <a href="user_bookings.php" class="card text-decoration-none" data-aos="zoom-in" data-aos-delay="300">
      <h3><i class="fas fa-list-check"></i> My Bookings</h3>
      <p>View and manage your bookings</p>
    </a>
  </div>
</div>

<footer id="footer">
  <p>&copy; 2025 Zed Group of Companies</p>
</footer>

<script>
  function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('collapsed');
    document.getElementById('mainContent').classList.toggle('collapsed');
    document.getElementById('footer').classList.toggle('collapsed');
    document.getElementById('toggleBtn').classList.toggle('collapsed');
  }
</script>

<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script> AOS.init(); </script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
