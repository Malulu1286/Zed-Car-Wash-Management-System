<?php
session_start();
include '../includes/config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking_id'])) {
    $booking_id = $_POST['booking_id'];
    $customer_id = $_SESSION['user_id'];

    // Only allow deleting their own booking
    $stmt = $dbh->prepare("DELETE FROM bookings WHERE booking_id = ? AND customer_id = ?");
    $stmt->execute([$booking_id, $customer_id]);
}

header("Location: user_bookings.php");
exit();
