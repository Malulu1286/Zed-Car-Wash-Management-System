<?php  
session_start();
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_name'])) {
    header("Location: user_login.php");
    exit();
}

include '../includes/config.php';

$customer_id = $_SESSION['user_id'];
$stmt = $dbh->prepare("SELECT customer_name, customer_phone, email FROM customers WHERE customer_id = ?");
$stmt->execute([$customer_id]);
$customer = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Book Service - Zed Car Wash</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />
  <link href="https://unpkg.com/aos@2.3.4/dist/aos.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet" />

  <style>
    /* Base styles */
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Poppins', sans-serif;
      color: #333;
      background: #fff;
      background-size: cover;
      overflow-x: hidden;
      min-height: 100vh;
    }

    /* Sidebar styles (same as your dashboard) */
    .sidebar {
      width: 260px;
      background-color: #f8f9fa;
      color: #000;
      display: flex;
      flex-direction: column;
      padding: 40px 20px;
      position: fixed;
      top: 0; bottom: 0;
      z-index: 1;
      transition: transform 0.3s ease-in-out;
      border-right: 1px solid #ddd;
    }
    .sidebar.collapsed { transform: translateX(-100%); }
    .toggle-btn {
      position: fixed;
      top: 20px; left: 270px;
      z-index: 2;
      background-color: rgba(0, 0, 0, 0.05);
      border: none;
      color: #000;
      padding: 10px 14px;
      font-size: 18px;
      cursor: pointer;
      border-radius: 6px;
      transition: left 0.3s ease-in-out;
    }
    .sidebar.collapsed ~ .toggle-btn { left: 10px; }
    .sidebar h2 {
      text-align: center;
      font-size: 22px;
      margin-bottom: 30px;
      font-weight: 600;
      color: #00bfff;
    }
    .sidebar a {
      text-decoration: none;
      color: #333;
      padding: 12px 18px;
      border-radius: 6px;
      margin-bottom: 14px;
      font-size: 15px;
      transition: background 0.3s;
    }
    .sidebar a:hover {
      background-color: #e7f5ff;
      color: #007bff;
    }
    .sidebar a.active {
      background-color: #e7f5ff;
      color: #007bff;
      font-weight: 600;
    }

    /* Main content */
    .main-content {
      margin-left: 260px;
      padding: 50px;
      background-color: rgba(255,255,255,0.95);
      min-height: 100vh;
      transition: margin-left 0.3s ease-in-out;
      font-family: 'Inter', sans-serif;
      color: #333;
    }
    .main-content.collapsed { margin-left: 0; padding: 30px 20px; }

    /* Booking form container */
    .container-glass {
      max-width: 700px;
      margin: 0 auto;
      padding: 40px;
      background: #fff;
      border-radius: 20px;
      box-shadow: 0 6px 18px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      margin-bottom: 30px;
      font-weight: 700;
      color: #00bfff;
      font-family: 'Poppins', sans-serif;
    }

    label {
      margin-top: 10px;
      font-weight: 600;
      display: block;
    }
    input, select {
      width: 100%;
      padding: 12px;
      margin-top: 6px;
      margin-bottom: 20px;
      border: 1px solid #ccc;
      border-radius: 8px;
      font-size: 16px;
      font-family: 'Inter', sans-serif;
    }
    input:focus, select:focus {
      border-color: #00bfff;
      background-color: #f1f9ff;
      outline: none;
    }
    button[type="submit"] {
      width: 100%;
      padding: 14px;
      background-color: #00bfff;
      color: #fff;
      font-weight: 700;
      font-size: 18px;
      border: none;
      border-radius: 10px;
      transition: background-color 0.3s ease;
      cursor: pointer;
      font-family: 'Poppins', sans-serif;
    }
    button[type="submit"]:hover {
      background-color: #0090cc;
    }
    .back-link {
      text-align: center;
      margin-top: 20px;
    }
    .back-link a {
      color: #00bfff;
      text-decoration: none;
      font-weight: 600;
    }
    .back-link a:hover {
      color: #007acc;
    }

    #mobile_payment_fields, #card_payment_fields {
      display: none;
      margin-bottom: 20px;
      background-color: #f1f9ff;
      padding: 16px;
      border-radius: 10px;
    }

    /* Footer */
    footer {
      text-align: center;
      padding: 15px 0;
      background-color: #f1f1f1;
      color: #555;
      font-size: 0.95rem;
      margin-top: 40px;
      margin-left: 260px;
      transition: margin-left 0.3s ease-in-out;
    }
    footer.collapsed {
      margin-left: 0;
    }

    @media (max-width: 768px) {
      .main-content {
        margin-left: 0;
        padding: 30px 20px;
      }
      footer {
        margin-left: 0;
      }
      .sidebar {
        transform: translateX(-100%);
      }
      .toggle-btn {
        left: 10px !important;
      }
    }
  </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar" id="sidebar">
  <h2><i class="fas fa-gauge"></i> User Dashboard</h2>
  <a href="../index.php"><i class="fas fa-home me-2"></i>Home</a>
  <a href="bookings.php" class="active"><i class="fas fa-calendar-check me-2"></i>Book a Service</a>
  <a href="user_bookings.php"><i class="fas fa-list-check me-2"></i>My Bookings</a>
  <a href="edit_profile.php"><i class="fas fa-user-edit me-2"></i>Edit Profile</a>
  <a href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
</div>

<button class="toggle-btn" onclick="toggleSidebar()" id="toggleBtn"><i class="fas fa-bars"></i></button>

<!-- Main content -->
<div class="main-content" id="mainContent" data-aos="fade-up" data-aos-delay="200" data-aos-duration="1000">

  <div class="container-glass" data-aos="fade-up">
    <h2><i class="fas fa-calendar-check me-2"></i>Book a Car Wash Service</h2>
    <form action="process_booking.php" method="POST" novalidate>

      <label for="customer_name">Full Name:</label>
      <input type="text" id="customer_name" name="customer_name"
             value="<?= htmlspecialchars($customer['customer_name']) ?>" required>

      <label for="customer_phone">Phone Number:</label>
      <input type="text" id="customer_phone" name="customer_phone"
             value="<?= htmlspecialchars($customer['customer_phone']) ?>" required>

      <label for="customer_email">Email:</label>
      <input type="email" id="customer_email" name="customer_email"
             value="<?= htmlspecialchars($customer['email']) ?>" required>

      <label for="service_id">Choose Service:</label>
      <select id="service_id" name="service_id" required>
        <option value="" disabled selected>-- Select Service --</option>
        <?php
        $stmt = $dbh->query("SELECT service_id, service_name, price FROM services ORDER BY price ASC");
        foreach ($stmt as $service) {
            echo "<option value='{$service['service_id']}'>" . htmlspecialchars($service['service_name']) . " - " . number_format($service['price']) . " TZS</option>";
        }
        ?>
      </select>

      <label for="appointment_date">Appointment Date:</label>
      <input type="datetime-local" id="appointment_date" name="appointment_date" required>

      <label for="payment_method">Payment Method:</label>
      <select id="payment_method" name="payment_method" required>
        <option value="" disabled selected>-- Select Method --</option>
        <option value="Cash">Cash</option>
        <option value="Mobile Payment">Mobile Payment</option>
        <option value="Card">Card</option>
      </select>

      <!-- Mobile Payment Fields -->
      <div id="mobile_payment_fields">
        <label for="mobile_number">Mobile Number:</label>
        <input type="text" id="mobile_number" name="mobile_number" placeholder="e.g. 0712xxxxxx">
      </div>

      <!-- Card Payment Fields -->
      <div id="card_payment_fields">
        <label for="card_number">Card Number:</label>
        <input type="text" id="card_number" name="card_number" placeholder="1234 5678 9012 3456">

        <label for="card_expiry">Expiry Date:</label>
        <input type="text" id="card_expiry" name="card_expiry" placeholder="MM/YY">
      </div>

      <button type="submit"><i class="fas fa-paper-plane me-2"></i>Submit Booking</button>

      <div class="back-link">
        <a href="user_dashboard.php"><i class="fas fa-arrow-left me-1"></i>Back to Dashboard</a>
      </div>
    </form>
  </div>

</div>

<!-- Footer -->
<footer id="footer">
  <p>&copy; 2025 Zed Group of Companies</p>
</footer>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init({ duration: 1000, once: true });

  function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('collapsed');
    document.getElementById('mainContent').classList.toggle('collapsed');
    document.getElementById('footer').classList.toggle('collapsed');
    document.getElementById('toggleBtn').classList.toggle('collapsed');
  }

  const dateInput = document.getElementById('appointment_date');
  const now = new Date();
  now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
  dateInput.min = now.toISOString().slice(0, 16);

  const paymentSelect = document.getElementById('payment_method');
  const mobileFields = document.getElementById('mobile_payment_fields');
  const cardFields = document.getElementById('card_payment_fields');

  paymentSelect.addEventListener('change', function () {
    mobileFields.style.display = 'none';
    cardFields.style.display = 'none';
    if (this.value === 'Mobile Payment') mobileFields.style.display = 'block';
    if (this.value === 'Card') cardFields.style.display = 'block';
  });
</script>

</body>
</html>
