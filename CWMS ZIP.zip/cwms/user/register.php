<?php
session_start();
include '../includes/config.php';

$error = '';
$success = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Trim inputs
    $name = trim($_POST['fullname'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    // Validation
    if (empty($name) || empty($phone) || empty($email) || empty($password) || empty($confirm)) {
        $error = 'Please fill in all fields.';
    } elseif (!preg_match("/^[a-zA-Z\s]+$/", $name)) {
        $error = 'Full name must contain only letters and spaces.';
    } elseif (!preg_match("/^\d+$/", $phone)) {
        $error = 'Phone number must contain digits only.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters long.';
    } elseif (!preg_match('/[\W_]/', $password)) {
        $error = 'Password must include at least one special character.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        // Check if email exists and insert
        try {
            $check = $dbh->prepare("SELECT * FROM customers WHERE email = ?");
            $check->execute([$email]);
            if ($check->rowCount() > 0) {
                $error = 'Email is already registered.';
            } else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $dbh->prepare("INSERT INTO customers (customer_name, customer_phone, email, password) VALUES (?, ?, ?, ?)");
                $stmt->execute([$name, $phone, $email, $hashed_password]);
                $success = 'Registration successful! Redirecting to login page...';
            }
        } catch (PDOException $e) {
            $error = "Registration failed: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>User Registration | Car Wash System</title>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet" />
  <!-- AOS animations -->
  <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet" />

  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f8f9fa;
      color: #333;
      min-height: 100vh;
    }
    header {
      background: #fff;
      padding: 15px 30px;
      border-bottom: 1px solid #ddd;
    }
    nav {
      display: flex;
      justify-content: center;
      gap: 16px;
      flex-wrap: wrap;
    }
    nav a {
      color: #00bfff;
      text-decoration: none;
      font-weight: 600;
      font-size: 1rem;
      padding: 8px 14px;
      border-radius: 6px;
      transition: background 0.3s ease, color 0.3s ease;
      display: flex;
      align-items: center;
      gap: 6px;
    }
    nav a:hover {
      background-color: #e7f5ff;
      color: #007bff;
    }
    .register-wrapper {
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 50px 20px;
      min-height: calc(100vh - 100px);
    }
    .container {
      background: #fff;
      padding: 40px;
      border-radius: 14px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
      width: 100%;
      max-width: 500px;
    }
    h2 {
      text-align: center;
      color: #00bfff;
      margin-bottom: 30px;
      font-weight: 600;
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 8px;
    }
    label {
      font-weight: 600;
      color: #333;
    }
    .form-control {
      padding: 12px;
      margin-bottom: 20px;
      border-radius: 8px;
    }
    .btn-primary {
      background-color: #0090cc;
      border: none;
      font-weight: 600;
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 6px;
    }
    .btn-primary:hover {
      background-color: #00bfff;
    }
    .form-footer {
      text-align: center;
      margin-top: 18px;
    }
    .form-footer a {
      text-decoration: none;
      color: #00bfff;
      font-weight: 500;
    }
    .form-footer a:hover {
      color: #007bff;
    }
    .error {
      color: #dc3545;
      text-align: center;
      font-weight: 500;
      margin-bottom: 20px;
    }
    .success {
      color: #28a745;
      text-align: center;
      font-weight: 600;
      margin-bottom: 20px;
    }
    footer {
      text-align: center;
      padding: 16px 0;
      background-color: #f1f1f1;
      font-size: 0.9rem;
      color: #555;
    }
  </style>
</head>
<body>

<header>
  <nav>
    <a href="../index.php"><i class="bi bi-house-fill"></i> Home</a>
    <a href="../services.php"><i class="bi bi-list-check"></i> Services</a>
    <a href="../user/user_dashboard.php"><i class="bi bi-person-fill"></i> User</a>
    <a href="../admin/admin_dashboard.php"><i class="bi bi-person-gear"></i> Admin</a>
    <a href="../contact.php"><i class="bi bi-envelope-fill"></i> Contact</a>
    <a href="../about.php"><i class="bi bi-info-circle-fill"></i> About</a>
  </nav>
</header>

<div class="register-wrapper" data-aos="zoom-in">
  <div class="container">
    <h2><i class="bi bi-person-plus-fill"></i> Create Your Account</h2>

    <?php if ($error): ?>
      <div class="error"><?= htmlspecialchars($error); ?></div>
    <?php elseif ($success): ?>
      <div class="success" id="success-message"><?= htmlspecialchars($success); ?></div>
      <script>
        // Redirect to login page after 1.5 seconds
        setTimeout(() => {
          window.location.href = 'user_login.php';
        }, 1500);
      </script>
    <?php endif; ?>

    <?php if (!$success): ?>
    <form method="POST" novalidate>
      <div class="mb-3">
        <label for="fullname">Full Name</label>
        <input
          type="text"
          id="fullname"
          name="fullname"
          class="form-control"
          required
          placeholder="Your full name"
          value="<?= htmlspecialchars($_POST['fullname'] ?? '') ?>"
          pattern="[a-zA-Z\s]+"
          title="Full name should contain letters and spaces only."
        />
      </div>

      <div class="mb-3">
        <label for="phone">Phone Number</label>
        <input
          type="text"
          id="phone"
          name="phone"
          class="form-control"
          required
          placeholder="e.g. 0712345678"
          value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>"
          pattern="\d+"
          title="Phone number should contain digits only."
        />
      </div>

      <div class="mb-3">
        <label for="email">Email Address</label>
        <input
          type="email"
          id="email"
          name="email"
          class="form-control"
          required
          placeholder="you@example.com"
          value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
        />
      </div>

      <div class="mb-3">
        <label for="password">Password</label>
        <input
          type="password"
          id="password"
          name="password"
          class="form-control"
          required
          placeholder="Enter password"
          minlength="6"
          pattern="(?=.*[\W_]).{6,}"
          title="Password must be at least 6 characters and include at least one special character."
        />
      </div>

      <div class="mb-3">
        <label for="confirm_password">Confirm Password</label>
        <input
          type="password"
          id="confirm_password"
          name="confirm_password"
          class="form-control"
          required
          placeholder="Repeat password"
          minlength="6"
          pattern="(?=.*[\W_]).{6,}"
          title="Password must be at least 6 characters and include at least one special character."
        />
      </div>

      <div class="d-grid mb-3">
        <button type="submit" class="btn btn-primary">
          <i class="bi bi-person-plus"></i> Register
        </button>
      </div>
    </form>
    <?php endif; ?>

    <div class="form-footer">
      <p>Already have an account? <a href="user_login.php"><i class="bi bi-box-arrow-in-right"></i> Login here</a></p>
      <p><a href="../index.php"><i class="bi bi-arrow-left-circle"></i> Back to Home</a></p>
    </div>
  </div>
</div>

<footer>
  <p>&copy; 2025 Zed Group of Companies</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init({ duration: 700, once: true });

  // Optional: Client-side password match validation
  const form = document.querySelector('form');
  form?.addEventListener('submit', e => {
    const pwd = form.password.value;
    const confirmPwd = form.confirm_password.value;
    if (pwd !== confirmPwd) {
      e.preventDefault();
      alert('Passwords do not match.');
    }
  });
</script>

</body>
</html>
