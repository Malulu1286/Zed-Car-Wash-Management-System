<?php
include 'includes/config.php';

if ($dbh) {
    echo "✅ Database connection successful!";
} else {
    echo "❌ Failed to connect to the database.";
}
?>
<footer>
        <p>&copy; 2025 Zed Group of Companies</p>
    </footer>
