<?php  
session_start();

// Ensure admin is logged in
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header("Location: ../admin/admin_login.php");
    exit();
}

include '../includes/config.php'; // Database connection
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard</title>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- FontAwesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <!-- AOS -->
  <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">

  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Poppins', sans-serif;
      color: #333;
      background-color: #fff;
      overflow-x: hidden;
      position: relative;
      min-height: 100vh;
    }

    /* Removed background image and dark overlays */

    .sidebar {
      width: 260px;
      background-color: #f8f9fa; /* light sidebar bg */
      color: #333;
      display: flex;
      flex-direction: column;
      padding: 40px 20px;
      position: fixed;
      top: 0;
      bottom: 0;
      z-index: 1;
      transition: transform 0.3s ease-in-out;
      border-right: 1px solid #ddd;
    }

    .sidebar.collapsed {
      transform: translateX(-100%);
    }

    .toggle-btn {
      position: fixed;
      top: 20px;
      left: 270px;
      z-index: 2;
      background-color: #e7f5ff;
      border: none;
      color: #007bff;
      padding: 10px 14px;
      font-size: 18px;
      cursor: pointer;
      border-radius: 6px;
      transition: left 0.3s ease-in-out;
    }

    .sidebar.collapsed ~ .toggle-btn {
      left: 10px;
    }

    .sidebar h2 {
      text-align: center;
      font-size: 22px;
      margin-bottom: 30px;
      font-weight: 600;
      letter-spacing: 1px;
      color: #007bff;
    }

    .sidebar a {
      text-decoration: none;
      color: #333;
      padding: 12px 18px;
      border-radius: 6px;
      margin-bottom: 14px;
      font-size: 15px;
      transition: background 0.3s;
    }

    .sidebar a:hover {
      background-color: #007bff;
      color: #fff;
    }

    .main-content {
      margin-left: 260px;
      padding: 50px;
      flex: 1;
      z-index: 1;
      transition: margin-left 0.3s ease-in-out;
    }

    .main-content.collapsed {
      margin-left: 0;
    }

    .main-content h1 {
      font-size: 26px;
      color: #007bff;
      margin-bottom: 30px;
      /* Removed text-shadow for cleaner light theme */
    }

    .card-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
      gap: 24px;
    }

    .card {
      background: #e7f5ff; /* light blue card bg */
      border: 1px solid #b3d7ff;
      border-radius: 14px;
      padding: 24px;
      color: #333;
      text-align: center;
      transition: transform 0.3s ease;
      box-shadow: 0 8px 20px rgba(0, 123, 255, 0.15);
      text-decoration: none;
      display: block;
    }

    .card:hover {
      transform: translateY(-5px);
      background-color: #cce5ff;
    }

    .card h3 {
      font-size: 18px;
      margin-bottom: 10px;
      color: #007bff;
    }

    .card p {
      font-size: 14px;
      color: #555;
    }

    footer {
      position: fixed;
      bottom: 0;
      left: 260px;
      right: 0;
      background-color: #f8f9fa;
      color: #555;
      text-align: center;
      padding: 12px 0;
      font-size: 14px;
      border-top: 1px solid #ddd;
      transition: left 0.3s ease-in-out;
    }

    footer.collapsed {
      left: 0;
    }

    @media (max-width: 768px) {
      .main-content {
        margin-left: 0;
        padding: 30px 20px;
      }

      footer {
        left: 0;
      }
    }
  </style>
</head>
<body>

<div class="sidebar" id="sidebar">
  <h2><i class="fas fa-gauge"></i> Admin Dashboard</h2>
  <a href="../index.php"><i class="fas fa-home me-2"></i>Home</a>
  <a href="../admin/manage_services.php"><i class="fas fa-concierge-bell me-2"></i>Manage Services</a>
  <a href="../admin/manage_users.php"><i class="fas fa-users-cog me-2"></i>Manage Users</a>
  <a href="../admin/view_bookings.php"><i class="fas fa-calendar-check me-2"></i>View All Bookings</a>
  <a href="../admin/admin_stats.php"><i class="fas fa-chart-line me-2"></i>View Statistics</a>
  <a href="../admin/admin_messages.php"><i class="fas fa-envelope me-2"></i>Contact Messages</a>
  <a href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
</div>

<button class="toggle-btn" onclick="toggleSidebar()" id="toggleBtn"><i class="fas fa-bars"></i></button>

<div class="main-content" id="mainContent" data-aos="fade-up" data-aos-delay="200" data-aos-duration="1000">
  <h1>Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</h1>
  <div class="card-grid">
    <a href="../admin/manage_services.php" class="card text-decoration-none" data-aos="zoom-in">
      <h3><i class="fas fa-tools"></i> Services</h3>
      <p>Manage wash services offered to customers</p>
    </a>

    <a href="../admin/manage_users.php" class="card text-decoration-none" data-aos="zoom-in" data-aos-delay="100">
      <h3><i class="fas fa-user-shield"></i> Users</h3>
      <p>View and manage user accounts</p>
    </a>

    <a href="../admin/view_bookings.php" class="card text-decoration-none" data-aos="zoom-in" data-aos-delay="200">
      <h3><i class="fas fa-book"></i> Bookings</h3>
      <p>Track and manage all service bookings</p>
    </a>

    <a href="../admin/admin_stats.php" class="card text-decoration-none" data-aos="zoom-in" data-aos-delay="300">
      <h3><i class="fas fa-chart-bar"></i> Statistics</h3>
      <p>Review users, booking, service and messages analytics</p>
    </a>

    <a href="../admin/admin_messages.php" class="card text-decoration-none" data-aos="zoom-in" data-aos-delay="400">
      <h3><i class="fas fa-comments"></i> Messages</h3>
      <p>Read messages and feedback from the customers</p>
    </a> 
  </div>
</div>

<footer id="footer">
  <p>&copy; 2025 Zed Group of Companies</p>
</footer>

<script>
  function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('collapsed');
    document.getElementById('mainContent').classList.toggle('collapsed');
    document.getElementById('footer').classList.toggle('collapsed');
    document.getElementById('toggleBtn').classList.toggle('collapsed');
  }
</script>

<!-- AOS JS -->
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init();
</script>

<!-- Bootstrap JS (Optional) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
