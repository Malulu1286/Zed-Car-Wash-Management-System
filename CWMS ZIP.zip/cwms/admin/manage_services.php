<?php
session_start();

// Ensure admin is logged in
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header("Location: ../admin/admin_login.php");
    exit();
}

include '../includes/config.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Manage Services</title>

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- FontAwesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <!-- AOS -->
  <link href="https://unpkg.com/aos@2.3.4/dist/aos.css" rel="stylesheet" />
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">

  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f8f9fa;
      color: #333;
      min-height: 100vh;
      overflow-x: hidden;
    }

    .sidebar {
      width: 260px;
      background-color: #f8f9fa;
      color: #333;
      display: flex;
      flex-direction: column;
      padding: 40px 20px;
      position: fixed;
      top: 0;
      bottom: 0;
      z-index: 1;
      transition: transform 0.3s ease-in-out;
      border-right: 1px solid #ddd;
    }

    .sidebar.collapsed {
      transform: translateX(-100%);
    }

    .toggle-btn {
      position: fixed;
      top: 20px;
      left: 270px;
      z-index: 2;
      background-color: #e7f5ff;
      border: none;
      color: #007bff;
      padding: 10px 14px;
      font-size: 18px;
      cursor: pointer;
      border-radius: 6px;
      transition: left 0.3s ease-in-out;
    }

    .sidebar.collapsed ~ .toggle-btn {
      left: 10px;
    }

    .sidebar h2 {
      text-align: center;
      font-size: 22px;
      margin-bottom: 30px;
      font-weight: 600;
      color: #007bff;
    }

    .sidebar a {
      text-decoration: none;
      color: #333;
      padding: 12px 18px;
      border-radius: 6px;
      margin-bottom: 14px;
      font-size: 15px;
      transition: background 0.3s;
    }

    .sidebar a:hover {
      background-color: #007bff;
      color: #fff;
    }

    .main-content {
      margin-left: 260px;
      padding: 60px 30px 100px;
      transition: margin-left 0.3s ease-in-out;
    }

    .main-content.collapsed {
      margin-left: 0;
    }

    .container-custom {
      background: #fff;
      padding: 40px;
      border-radius: 16px;
      box-shadow: 0 10px 40px rgba(0, 123, 255, 0.1);
    }

    h2 {
      color: #007bff;
    }

    .btn-success {
      background-color: #28a745;
      border: none;
    }

    .btn-success:hover {
      background-color: #218838;
    }

    .card {
      border: 1px solid #dee2e6;
      border-radius: 10px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.05);
      transition: transform 0.3s ease;
    }

    .card:hover {
      transform: translateY(-5px);
    }

    .card-title {
      color: #007bff;
      font-size: 1.2rem;
      font-weight: 600;
    }

    .card-text {
      color: #555;
    }

    .card-actions a {
      margin-right: 15px;
      color: #007bff;
      font-weight: 500;
      text-decoration: none;
    }

    .card-actions a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<div class="sidebar" id="sidebar">
  <h2><i class="fas fa-gauge"></i> Admin Dashboard</h2>
  <a href="../index.php"><i class="fas fa-home me-2"></i>Home</a>
  <a href="../admin/manage_services.php"><i class="fas fa-concierge-bell me-2"></i>Manage Services</a>
  <a href="../admin/manage_users.php"><i class="fas fa-users-cog me-2"></i>Manage Users</a>
  <a href="../admin/view_bookings.php"><i class="fas fa-calendar-check me-2"></i>View All Bookings</a>
  <a href="../admin/admin_stats.php"><i class="fas fa-chart-line me-2"></i>View Statistics</a>
  <a href="../admin/admin_messages.php"><i class="fas fa-envelope me-2"></i>Contact Messages</a>
  <a href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
</div>

<button class="toggle-btn" onclick="toggleSidebar()" id="toggleBtn"><i class="fas fa-bars"></i></button>

<div class="main-content" id="mainContent" data-aos="fade-up">
  <div class="container container-custom">
    <h2 class="text-center mb-4"><i class="fas fa-cogs me-2"></i>Manage Services</h2>

    <div class="d-flex justify-content-end mb-4">
      <a href="add_service.php" class="btn btn-success">
        <i class="fas fa-plus-circle me-1"></i> Add New Service
      </a>
    </div>

    <div class="row g-4">
      <?php
      $icons = ['fa-car', 'fa-water', 'fa-broom', 'fa-oil-can', 'fa-spray-can-sparkles', 'fa-bolt'];
      $stmt = $dbh->query("SELECT * FROM services");
      $i = 0;
      foreach ($stmt as $row):
        $icon = $icons[$i % count($icons)];
        $i++;
      ?>
        <div class="col-md-6 col-lg-4" data-aos="zoom-in">
          <div class="card h-100">
            <div class="card-body">
              <h5 class="card-title"><i class="fas <?= $icon ?> me-2"></i><?= htmlspecialchars($row['service_name']); ?></h5>
              <p class="card-text"><?= nl2br(htmlspecialchars($row['description'])); ?></p>
              <p class="card-text"><strong>Price:</strong> TZS <?= number_format($row['price']); ?></p>
            </div>
            <div class="card-footer bg-transparent border-0 card-actions">
              <a href="edit_service.php?name=<?= urlencode($row['service_name']); ?>"><i class="fas fa-edit"></i> Edit</a>
              <a href="delete_service.php?name=<?= urlencode($row['service_name']); ?>" onclick="return confirm('Delete this service?');"><i class="fas fa-trash-alt"></i> Delete</a>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <div class="text-center mt-5">
      <a href="../admin/admin_dashboard.php" class="btn btn-outline-primary"><i class="fas fa-arrow-left me-1"></i> Back to Dashboard</a>
    </div>
  </div>
</div>

<script>
  function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('collapsed');
    document.getElementById('mainContent').classList.toggle('collapsed');
    document.getElementById('footer').classList.toggle('collapsed');
    document.getElementById('toggleBtn').classList.toggle('collapsed');
  }
</script>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- AOS JS -->
<script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init();
</script>

</body>
</html>
