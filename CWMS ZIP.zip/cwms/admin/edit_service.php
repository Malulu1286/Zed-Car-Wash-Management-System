<?php
session_start();
if (!isset($_SESSION['user_name'])) {
    header("Location: user_login.html");
    exit();
}
include '../includes/config.php';

$service_id = $_GET['name'] ?? null;
$success = '';

if (!$service_id) {
    die("Service name is missing.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['service_name'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    if (empty($name) || empty($description) || empty($price)) {
        $error = 'All fields are required.';
    } else {
        $stmt = $dbh->prepare("UPDATE services SET service_name = ?, description = ?, price = ? WHERE service_name = ?");
        $stmt->execute([$name, $description, $price, $service_id]);
        $success = 'Service updated successfully. Redirecting...';
        echo "<script>setTimeout(() => { window.location.href = 'manage_services.php'; }, 2000);</script>";
    }
}

$stmt = $dbh->prepare("SELECT * FROM services WHERE service_name = ?");
$stmt->execute([$service_id]);
$service = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$service) {
    die("Service not found.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Edit Service</title>

  <!-- Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <!-- FontAwesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />
  <!-- AOS -->
  <link href="https://unpkg.com/aos@2.3.4/dist/aos.css" rel="stylesheet" />
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />

  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f8f9fa;
      color: #333;
      min-height: 100vh;
    }

    .container-custom {
      max-width: 700px;
      margin: 80px auto;
      padding: 50px 40px;
      background: #fff;
      border-radius: 30px;
      box-shadow: 0 12px 48px rgba(0, 191, 255, 0.1);
    }

    h2 {
      color: #007bff;
      text-align: center;
      margin-bottom: 30px;
    }

    label {
      font-weight: 600;
      margin-top: 15px;
      color: #333;
    }

    input[type="text"],
    input[type="number"],
    textarea {
      width: 100%;
      padding: 12px 15px;
      border-radius: 10px;
      border: 1px solid #ced4da;
      font-size: 1rem;
      background-color: #fff;
      color: #333;
      box-shadow: inset 0 0 5px rgb(0 0 0 / 0.05);
    }

    input:focus,
    textarea:focus {
      outline: none;
      border-color: #007bff;
      box-shadow: 0 0 10px rgba(0, 123, 255, 0.2);
    }

    button {
      margin-top: 30px;
      width: 100%;
      background-color: #28a745;
      border: none;
      padding: 14px;
      border-radius: 10px;
      font-size: 1.1rem;
      color: white;
      cursor: pointer;
      transition: background-color 0.3s ease;
      font-weight: 600;
    }

    button:hover {
      background-color: #218838;
    }

    .back-link {
      display: block;
      margin-top: 20px;
      text-align: center;
      color: #007bff;
      font-weight: 500;
      text-decoration: none;
    }

    .back-link:hover {
      text-decoration: underline;
    }

    .alert-success {
      margin-top: 20px;
      font-size: 1rem;
      text-align: center;
      color: #155724;
      background-color: #d4edda;
      border: 1px solid #c3e6cb;
      padding: 15px;
      border-radius: 10px;
    }

    footer {
      text-align: center;
      padding: 20px 0;
      color: #777;
      background-color: #f1f1f1;
      font-size: 0.9rem;
      margin-top: 60px;
    }

    @media (max-width: 700px) {
      .container-custom {
        margin: 40px 20px;
        padding: 30px 20px;
      }
      h2 {
        font-size: 1.6rem;
      }
    }
  </style>
</head>
<body>

<div class="container-custom" data-aos="fade-up">
  <h2><i class="fas fa-edit me-2"></i>Edit Service</h2>

  <?php if (!empty($success)): ?>
    <div class="alert-success"><?= $success ?></div>
  <?php endif; ?>

  <form method="POST">
    <label for="service_name">Service Name:</label>
    <input type="text" name="service_name" id="service_name" required value="<?= htmlspecialchars($service['service_name']) ?>" />

    <label for="description">Description:</label>
    <textarea name="description" id="description" rows="4" required><?= htmlspecialchars($service['description']) ?></textarea>

    <label for="price">Price (TZS):</label>
    <input type="number" name="price" id="price" min="0" required value="<?= htmlspecialchars($service['price']) ?>" />

    <button type="submit"><i class="fas fa-check-circle me-1"></i> Update Service</button>
  </form>

  <a href="manage_services.php" class="back-link"><i class="fas fa-arrow-left me-1"></i> Back to Services</a>
</div>

<footer>
  <p>&copy; 2025 Zed Group of Companies</p>
</footer>

<!-- Bootstrap Bundle JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- AOS -->
<script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init();
</script>

</body>
</html>
