<?php 
session_start();

// Ensure admin is logged in
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header("Location: ../admin/admin_login.php");
    exit();
}

include '../includes/config.php';

$successMessage = '';

// Handle deletion if POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_user'])) {
    $userNameToDelete = $_POST['delete_user'];
    $deleteStmt = $dbh->prepare("DELETE FROM customers WHERE customer_name = ?");
    if ($deleteStmt->execute([$userNameToDelete])) {
        $successMessage = "User '" . htmlspecialchars($userNameToDelete) . "' deleted successfully.";
    } else {
        $successMessage = "Error deleting user '" . htmlspecialchars($userNameToDelete) . "'.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Manage Users</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <!-- FontAwesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />
  <!-- AOS -->
  <link href="https://unpkg.com/aos@2.3.4/dist/aos.css" rel="stylesheet" />
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />

  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f8f9fa;
      color: #333;
      min-height: 100vh;
      overflow-x: hidden;
    }

    .sidebar {
      width: 260px;
      background-color: #f8f9fa;
      color: #333;
      display: flex;
      flex-direction: column;
      padding: 40px 20px;
      position: fixed;
      top: 0;
      bottom: 0;
      z-index: 1;
      border-right: 1px solid #ddd;
      transition: transform 0.3s ease-in-out;
    }

    .sidebar.collapsed {
      transform: translateX(-100%);
    }

    .toggle-btn {
      position: fixed;
      top: 20px;
      left: 270px;
      z-index: 2;
      background-color: #e7f5ff;
      border: none;
      color: #007bff;
      padding: 10px 14px;
      font-size: 18px;
      cursor: pointer;
      border-radius: 6px;
      transition: left 0.3s ease-in-out;
    }

    .sidebar.collapsed ~ .toggle-btn {
      left: 10px;
    }

    .sidebar h2 {
      text-align: center;
      font-size: 22px;
      margin-bottom: 30px;
      font-weight: 600;
      color: #007bff;
    }

    .sidebar a {
      text-decoration: none;
      color: #333;
      padding: 12px 18px;
      border-radius: 6px;
      margin-bottom: 14px;
      font-size: 15px;
      transition: background 0.3s;
    }

    .sidebar a:hover {
      background-color: #007bff;
      color: #fff;
    }

    .main-content {
      margin-left: 260px;
      padding: 60px 30px;
      transition: margin-left 0.3s ease-in-out;
    }

    .main-content.collapsed {
      margin-left: 0;
    }

    .container-custom {
      max-width: 1100px;
      margin: 0 auto;
      padding: 40px;
      background: #ffffff;
      border-radius: 16px;
      box-shadow: 0 12px 40px rgba(0, 123, 255, 0.1);
    }

    h2 {
      text-align: center;
      color: #007bff;
      margin-bottom: 30px;
      font-weight: 600;
    }

    .alert-success {
      margin-bottom: 20px;
    }

    table {
      width: 100%;
      border-collapse: separate;
      border-spacing: 0 12px;
      font-size: 1rem;
    }

    thead th {
      background-color: #007bff;
      color: white;
      padding: 14px 18px;
      border-radius: 8px 8px 0 0;
      text-align: left;
    }

    tbody tr {
      background-color: #f1f1f1;
      transition: background-color 0.3s ease;
    }

    tbody tr:hover {
      background-color: #e0eaff;
    }

    tbody td {
      padding: 14px 18px;
      vertical-align: middle;
    }

    .delete-button {
      color: #dc3545;
      font-weight: 600;
      background: none;
      border: none;
      cursor: pointer;
      padding: 0;
      font-size: 1rem;
      font-family: inherit;
    }

    .delete-button:hover {
      color: #c82333;
      text-decoration: underline;
    }

    .btn-dashboard {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      margin-top: 30px;
      padding: 12px 28px;
      background-color: #007bff;
      color: white;
      border-radius: 8px;
      font-size: 1.1rem;
      font-weight: 600;
      text-decoration: none;
      border: none;
      transition: background-color 0.3s ease;
    }

    .btn-dashboard:hover {
      background-color: #0056b3;
      text-decoration: none;
    }

    @media (max-width: 768px) {
      .main-content {
        margin-left: 0;
        padding: 30px 20px;
      }

      .container-custom {
        padding: 25px 20px;
      }

      h2 {
        font-size: 1.8rem;
      }

      table {
        font-size: 0.9rem;
      }

      .btn-dashboard {
        width: 100%;
        font-size: 1rem;
        padding: 14px;
      }
    }
  </style>
</head>
<body>

<div class="sidebar" id="sidebar">
  <h2><i class="fas fa-gauge"></i> Admin Dashboard</h2>
  <a href="../index.php"><i class="fas fa-home me-2"></i>Home</a>
  <a href="../admin/manage_services.php"><i class="fas fa-concierge-bell me-2"></i>Manage Services</a>
  <a href="../admin/manage_users.php"><i class="fas fa-users-cog me-2"></i>Manage Users</a>
  <a href="../admin/view_bookings.php"><i class="fas fa-calendar-check me-2"></i>View All Bookings</a>
  <a href="../admin/admin_stats.php"><i class="fas fa-chart-line me-2"></i>View Statistics</a>
  <a href="../admin/admin_messages.php"><i class="fas fa-envelope me-2"></i>Contact Messages</a>
  <a href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
</div>

<button class="toggle-btn" onclick="toggleSidebar()" id="toggleBtn"><i class="fas fa-bars"></i></button>

<div class="main-content" id="mainContent" data-aos="fade-up" data-aos-duration="900">
  <div class="container-custom">
    <h2><i class="fas fa-users me-2"></i>Registered Users</h2>

    <?php if ($successMessage): ?>
      <div class="alert alert-success" role="alert">
        <?php echo $successMessage; ?>
      </div>
    <?php endif; ?>

    <div class="table-responsive">
      <table class="table align-middle">
        <thead>
          <tr>
            <th>Name</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $stmt = $dbh->query("SELECT * FROM customers");
          foreach ($stmt as $row) {
              echo "<tr>
                      <td>" . htmlspecialchars($row['customer_name']) . "</td>
                      <td>" . htmlspecialchars($row['customer_phone']) . "</td>
                      <td>" . htmlspecialchars($row['email']) . "</td>
                      <td>
                        <form method='POST' style='display:inline;' onsubmit='return confirm(\"Are you sure you want to delete this user?\");'>
                          <input type='hidden' name='delete_user' value='" . htmlspecialchars($row['customer_name']) . "' />
                          <button type='submit' class='delete-button' title='Delete User'>
                            <i class='fas fa-trash-alt me-1'></i> Delete
                          </button>
                        </form>
                      </td>
                    </tr>";
          }
          ?>
        </tbody>
      </table>
    </div>

    <a href="admin_dashboard.php" class="btn-dashboard">
      <i class="fas fa-tachometer-alt me-2"></i> Go to Admin Dashboard
    </a>
  </div>
</div>

<script>
  function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('collapsed');
    document.getElementById('mainContent').classList.toggle('collapsed');
    document.getElementById('toggleBtn').classList.toggle('collapsed');
  }
</script>

<!-- JS Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init();
</script>

</body>
</html>
