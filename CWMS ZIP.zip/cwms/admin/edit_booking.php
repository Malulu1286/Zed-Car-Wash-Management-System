<?php
session_start();
include '../includes/config.php';

$booking_id = $_GET['id'] ?? null;
$message = "";

if (!$booking_id) {
    header("Location: view_bookings.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $status = $_POST['status'] ?? '';
    $appointment_date = $_POST['appointment_date'] ?? '';

    $allowed_statuses = ['Pending', 'Completed', 'Cancelled'];
    if (!in_array($status, $allowed_statuses, true)) {
        $message = "Error: Invalid booking status.";
    } else {
        $submittedTimestamp = strtotime($appointment_date);
        $currentTimestamp = time();

        if ($submittedTimestamp === false) {
            $message = "Error: Invalid appointment date format.";
        } elseif ($submittedTimestamp < $currentTimestamp) {
            $message = "Error: You cannot set an appointment date/time in the past.";
        } else {
            $stmt = $dbh->prepare("UPDATE bookings SET status = :status, appointment_date = :appointment_date WHERE booking_id = :booking_id");
            $updated = $stmt->execute([
                ':status' => $status,
                ':appointment_date' => $appointment_date,
                ':booking_id' => $booking_id,
            ]);

            if ($updated) {
                $message = "Booking updated successfully!";
                // Refresh booking info after update
                $stmt = $dbh->prepare("SELECT * FROM bookings WHERE booking_id = :booking_id");
                $stmt->execute([':booking_id' => $booking_id]);
                $booking = $stmt->fetch(PDO::FETCH_ASSOC);
            } else {
                $message = "Error: Failed to update booking.";
            }
        }
    }
}

$stmt = $dbh->prepare("SELECT * FROM bookings WHERE booking_id = :booking_id");
$stmt->execute([':booking_id' => $booking_id]);
$booking = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$booking) {
    echo "<p>Booking not found.</p><p><a href='view_bookings.php'>Back to bookings</a></p>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Edit Booking</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <!-- Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <!-- FontAwesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />
  <!-- AOS CSS -->
  <link href="https://unpkg.com/aos@2.3.4/dist/aos.css" rel="stylesheet" />
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />

  <style>
    body {
      font-family: 'Poppins', sans-serif;
      min-height: 100vh;
      overflow-x: hidden;
      color: #333;
      background-color: #f8f9fa;
      margin: 0;
      padding: 0;
    }

    .container-custom {
      max-width: 700px;
      margin: 60px auto;
      padding: 40px;
      background-color: #fff;
      border-radius: 16px;
      box-shadow: 0 8px 24px rgba(0, 123, 255, 0.15);
      color: #333;
    }

    h2 {
      text-align: center;
      color: #007bff;
      margin-bottom: 30px;
      font-weight: 600;
      font-size: 2.4rem;
    }

    form label {
      font-weight: 600;
      color: #333;
    }

    .form-control, .form-select {
      border-radius: 8px;
      background: #fff;
      color: #333;
      padding: 12px;
      font-weight: 500;
      border: 1px solid #ced4da;
      transition: border-color 0.3s ease;
    }

    .form-control:focus, .form-select:focus {
      border-color: #007bff;
      box-shadow: 0 0 6px rgba(0, 123, 255, 0.3);
      outline: none;
    }

    button.btn-primary {
      background-color: #007bff;
      border: none;
      font-weight: 700;
      padding: 12px;
      border-radius: 8px;
      width: 100%;
      font-size: 1.1rem;
      transition: background-color 0.3s ease, box-shadow 0.3s ease;
      box-shadow: 0 6px 12px rgba(0, 123, 255, 0.3);
      cursor: pointer;
      color: white;
    }

    button.btn-primary:hover {
      background-color: #0056b3;
      box-shadow: 0 8px 18px rgba(0, 86, 179, 0.5);
    }

    .alert-success, .alert-danger {
      border-radius: 8px;
      text-align: center;
      font-weight: 600;
      margin-bottom: 20px;
      user-select: none;
      padding: 15px 20px;
      font-size: 1rem;
    }

    .alert-success {
      background-color: #28a745;
      color: white;
      box-shadow: 0 4px 12px rgb(40 167 69 / 0.7);
    }

    .alert-danger {
      background-color: #dc3545;
      color: white;
      box-shadow: 0 4px 12px rgb(220 53 69 / 0.7);
    }

    .back-link {
      display: inline-flex;
      justify-content: center;
      align-items: center;
      margin-top: 30px;
      padding: 12px 28px;
      background-color: #007bff;
      color: white;
      border-radius: 8px;
      font-size: 1.1rem;
      font-weight: 600;
      text-decoration: none;
      user-select: none;
      box-shadow: 0 6px 12px rgba(0, 123, 255, 0.3);
      transition: background-color 0.3s ease, box-shadow 0.3s ease;
      width: 100%;
    }

    .back-link:hover {
      background-color: #0056b3;
      box-shadow: 0 8px 18px rgba(0, 86, 179, 0.5);
      text-decoration: none;
      color: white;
    }

    footer {
      text-align: center;
      padding: 20px 0;
      background-color: #f1f1f1;
      color: #555;
      font-size: 0.9rem;
      margin-top: 60px;
      user-select: none;
    }

    @media (max-width: 768px) {
      .container-custom {
        margin: 20px 15px;
        padding: 25px 20px;
      }

      h2 {
        font-size: 1.8rem;
      }

      button.btn-primary, .back-link {
        font-size: 1rem;
        padding: 14px;
      }
    }
  </style>
</head>
<body>

<div class="container-custom" data-aos="fade-up" data-aos-duration="900" data-aos-easing="ease-in-out">

  <h2><i class="fas fa-edit me-2"></i>Edit Booking</h2>

  <?php if ($message): ?>
    <div class="alert <?= str_starts_with($message, 'Error') ? 'alert-danger' : 'alert-success' ?>" role="alert">
      <?= htmlspecialchars($message) ?>
    </div>
  <?php endif; ?>

  <form method="POST" novalidate>
    <div class="mb-4">
      <label for="status" class="form-label">Booking Status <i class="fas fa-info-circle text-info"></i></label>
      <select name="status" id="status" class="form-select" required>
        <?php foreach (['Pending', 'Completed', 'Cancelled'] as $option): ?>
          <option value="<?= $option ?>" <?= ($booking['status'] === $option) ? 'selected' : '' ?>>
            <?= $option ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="mb-4">
      <label for="appointment_date" class="form-label">Appointment Date & Time <i class="fas fa-calendar-alt text-info"></i></label>
      <input
        type="datetime-local"
        id="appointment_date"
        name="appointment_date"
        class="form-control"
        value="<?= date('Y-m-d\TH:i', strtotime($booking['appointment_date'])) ?>"
        min="<?= date('Y-m-d\TH:i') ?>"
        required
      />
    </div>

    <button type="submit" class="btn btn-primary"><i class="fas fa-save me-2"></i>Update Booking</button>
  </form>

  <a href="view_bookings.php" class="back-link mt-4"><i class="fas fa-arrow-left me-2"></i>Back to Bookings</a>

</div>

<footer>
  &copy; <?= date('Y') ?> Car Wash Management System. All rights reserved.
</footer>

<!-- Bootstrap 5 JS Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- AOS JS -->
<script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init();
</script>

</body>
</html>
