<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: admin_login.php");
    exit();
}

include '../includes/config.php';

$booking_id = $_GET['id'] ?? null;
if (!$booking_id) {
    die("Booking ID is required.");
}

// Fetch booking info
$stmt = $dbh->prepare("
    SELECT b.booking_id, b.appointment_date, b.payment_method, b.status,
           c.customer_name, c.customer_phone, c.email,
           s.service_name, s.description, s.price
    FROM bookings b
    JOIN customers c ON b.customer_id = c.customer_id
    JOIN services s ON b.service_id = s.service_id
    WHERE b.booking_id = ?
");
$stmt->execute([$booking_id]);
$booking = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$booking) {
    die("Booking not found.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Booking Receipt</title>

<!-- Bootstrap 5 CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
<!-- FontAwesome for icons -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
<!-- AOS CSS for animations -->
<link href="https://unpkg.com/aos@2.3.4/dist/aos.css" rel="stylesheet" />
<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />

<style>
  body {
    min-height: 100vh;
    background-color: #f8f9fa;
    color: #333;
    font-family: 'Poppins', sans-serif;
    margin: 0;
    padding: 0;
  }

  .container-custom {
    max-width: 800px;
    margin: 60px auto 40px;
    background: #fff;
    border-radius: 16px;
    padding: 40px;
    box-shadow: 0 8px 24px rgba(0, 123, 255, 0.15);
  }

  h2 {
    color: #007bff;
    margin-bottom: 30px;
    font-weight: 700;
    text-align: center;
  }

  p {
    font-size: 1.1rem;
    margin-bottom: 12px;
  }

  hr {
    border-color: #007bff33;
    margin: 30px 0;
  }

  .btn-print {
    background-color: #007bff;
    border: none;
    color: white;
    font-weight: 600;
    padding: 12px 30px;
    border-radius: 8px;
    cursor: pointer;
    font-size: 1rem;
    transition: background-color 0.3s ease;
  }

  .btn-print:hover {
    background-color: #0056b3;
  }

  .back-link {
    display: block;
    margin-top: 15px;
    color: #007bff;
    font-weight: 600;
    text-decoration: none;
    text-align: center;
  }

  .back-link:hover {
    text-decoration: underline;
  }

  footer {
    text-align: center;
    padding: 20px 0;
    background-color: #e9ecef;
    color: #555;
    font-size: 0.9rem;
    user-select: none;
  }

  @media print {
    body {
      background: white;
      color: black;
      font-family: Arial, sans-serif;
    }
    .container-custom {
      box-shadow: none;
      padding: 0;
      border-radius: 0;
    }
    footer, .btn-print, .back-link {
      display: none;
    }
  }
</style>
</head>
<body>

<div class="container-custom" data-aos="fade-up" data-aos-duration="1500">
  <h2><i class="fa-solid fa-receipt"></i> Car Wash Booking Receipt</h2>

  <p><strong>Customer:</strong> <?= htmlspecialchars($booking['customer_name']) ?></p>
  <p><strong>Email:</strong> <?= htmlspecialchars($booking['email']) ?></p>
  <p><strong>Phone:</strong> <?= htmlspecialchars($booking['customer_phone']) ?></p>

  <hr />

  <p><strong>Service:</strong> <?= htmlspecialchars($booking['service_name']) ?></p>
  <p><strong>Description:</strong> <?= htmlspecialchars($booking['description']) ?></p>
  <p><strong>Price:</strong> <?= number_format($booking['price'], 2) ?> TZS</p>

  <hr />

  <p><strong>Appointment Date:</strong> <?= htmlspecialchars($booking['appointment_date']) ?></p>
  <p><strong>Payment Method:</strong> <?= htmlspecialchars($booking['payment_method']) ?></p>
  <p><strong>Status:</strong> <?= htmlspecialchars($booking['status']) ?></p>

  <div class="text-center mt-4">
    <button class="btn-print" onclick="window.print()"><i class="fa-solid fa-print"></i> Print Receipt</button>
    <a href="view_bookings.php" class="back-link"><i class="fa-solid fa-arrow-left"></i> Back to Bookings</a>
  </div>
</div>

<footer>
  &copy; 2025 Zed Group of Companies
</footer>

<!-- Bootstrap 5 JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- AOS JS -->
<script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init();
</script>

</body>
</html>
