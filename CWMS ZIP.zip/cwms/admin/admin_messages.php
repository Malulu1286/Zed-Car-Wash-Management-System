<?php
session_start();
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header("Location: ../admin/admin_login.php");
    exit();
}

include '../includes/config.php';

// Fetch all messages
$stmt = $dbh->query("SELECT * FROM messages ORDER BY created_at DESC");
$messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle delete request
if (isset($_GET['delete_id'])) {
    $delete_id = (int)$_GET['delete_id'];
    $stmt = $dbh->prepare("DELETE FROM messages WHERE id = :id");
    $stmt->bindParam(':id', $delete_id, PDO::PARAM_INT);
    $stmt->execute();
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Contact Messages - Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />
  <link href="https://unpkg.com/aos@2.3.4/dist/aos.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet" />
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f8f9fa;
      color: #212529;
      margin: 0;
      padding: 0;
    }

    .sidebar {
      width: 260px;
      background-color: #f8f9fa;
      padding: 40px 20px;
      position: fixed;
      top: 0;
      bottom: 0;
      z-index: 1000;
      transition: transform 0.3s ease-in-out;
      border-right: 1px solid #dee2e6;
    }

    .sidebar.collapsed {
      transform: translateX(-100%);
    }

    .toggle-btn {
      position: fixed;
      top: 20px;
      left: 270px;
      z-index: 1100;
      background-color: #e7f5ff;
      border: none;
      color: #007bff;
      padding: 10px 14px;
      font-size: 18px;
      cursor: pointer;
      border-radius: 6px;
      transition: left 0.3s ease-in-out;
    }

    .sidebar.collapsed ~ .toggle-btn {
      left: 10px;
    }

    .sidebar h2 {
      text-align: center;
      font-size: 22px;
      margin-bottom: 30px;
      font-weight: 600;
      color: #007bff;
    }

    .sidebar a {
      text-decoration: none;
      color: #333;
      padding: 12px 18px;
      border-radius: 6px;
      margin-bottom: 14px;
      display: block;
      font-size: 15px;
      transition: background 0.3s;
    }

    .sidebar a:hover {
      background-color: #007bff;
      color: #fff;
    }

    .sidebar a.active {
      background-color: #007bff;
      color: #fff;
      font-weight: 600;
    }

    .main-content {
      margin-left: 260px;
      padding: 50px;
      transition: margin-left 0.3s ease-in-out;
    }

    .main-content.collapsed {
      margin-left: 0;
      padding: 30px 20px;
    }

    .container-custom {
      background: #fff;
      padding: 40px;
      border-radius: 16px;
      box-shadow: 0 8px 32px rgba(0, 123, 255, 0.12);
      color: #212529;
    }

    h2.page-title {
      text-align: center;
      color: #0d6efd;
      margin-bottom: 30px;
      font-weight: 600;
      font-size: 2.4rem;
    }

    table {
      width: 100%;
      border-collapse: separate;
      border-spacing: 0 10px;
      font-size: 1rem;
      background: transparent;
      border-radius: 10px;
      overflow: hidden;
    }

    thead th {
      background-color: #0d6efd;
      color: white;
      font-size: 1.1rem;
      padding: 14px 18px;
      border-radius: 10px 10px 0 0;
      text-align: left;
    }

    tbody tr {
      background: #e9f0ff;
      box-shadow: 0 2px 8px rgba(13, 110, 253, 0.1);
      transition: background-color 0.3s ease;
      border-radius: 10px;
    }

    tbody tr:hover {
      background-color: #cfe2ff;
      box-shadow: 0 4px 16px rgba(13, 110, 253, 0.2);
    }

    tbody td {
      padding: 14px 18px;
      vertical-align: top;
      color: #212529;
    }

    .delete-link {
      color: #dc3545;
      font-weight: 600;
      text-decoration: none;
      font-size: 1rem;
    }

    .delete-link:hover {
      color: #a71d2a;
      text-decoration: underline;
    }

    .btn-dashboard {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      margin-top: 40px;
      padding: 14px 28px;
      background-color: #0d6efd;
      color: white;
      border-radius: 8px;
      font-size: 1.1rem;
      font-weight: 600;
      text-decoration: none;
      box-shadow: 0 6px 12px rgba(13, 110, 253, 0.4);
      border: none;
      cursor: pointer;
      gap: 10px;
      user-select: none;
    }

    .btn-dashboard:hover {
      background-color: #084298;
      box-shadow: 0 8px 18px rgba(8, 66, 152, 0.6);
      color: white;
    }

    @media (max-width: 768px) {
      .main-content {
        margin-left: 0;
        padding: 30px 20px;
      }

      .sidebar {
        transform: translateX(-100%);
      }

      .toggle-btn {
        left: 10px !important;
      }
    }
  </style>
</head>
<body>

<div class="sidebar" id="sidebar">
  <h2><i class="fas fa-gauge"></i> Admin Dashboard</h2>
  <a href="../index.php"><i class="fas fa-home me-2"></i>Home</a>
  <a href="manage_services.php"><i class="fas fa-concierge-bell me-2"></i>Manage Services</a>
  <a href="manage_users.php"><i class="fas fa-users-cog me-2"></i>Manage Users</a>
  <a href="view_bookings.php"><i class="fas fa-calendar-check me-2"></i>View All Bookings</a>
  <a href="admin_stats.php"><i class="fas fa-chart-line me-2"></i>View Statistics</a>
  <a href="admin_messages.php" class="active"><i class="fas fa-envelope me-2"></i>Contact Messages</a>
  <a href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
</div>

<button class="toggle-btn" onclick="toggleSidebar()" id="toggleBtn"><i class="fas fa-bars"></i></button>

<div class="main-content" id="mainContent" data-aos="fade-up">
  <div class="container-custom">
    <h2 class="page-title"><i class="fas fa-envelope me-2"></i>Contact Messages</h2>

    <?php if (count($messages) > 0): ?>
      <div class="table-responsive">
        <table>
          <thead>
            <tr>
              <th>Sender</th>
              <th>Email</th>
              <th>Message</th>
              <th>Received</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($messages as $msg): ?>
              <tr>
                <td><?= htmlspecialchars($msg['name']) ?></td>
                <td><?= htmlspecialchars($msg['email']) ?></td>
                <td><?= nl2br(htmlspecialchars($msg['message'])) ?></td>
                <td><?= htmlspecialchars($msg['created_at']) ?></td>
                <td>
                  <a href="?delete_id=<?= $msg['id'] ?>" 
                     class="delete-link" 
                     onclick="return confirm('Are you sure you want to delete this message?');">
                    <i class="fas fa-trash-alt"></i> Delete
                  </a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php else: ?>
      <p style="text-align: center; margin-top: 30px;">No messages found.</p>
    <?php endif; ?>

    <a href="admin_dashboard.php" class="btn-dashboard mt-5">
      <i class="fas fa-tachometer-alt"></i> Go to Admin Dashboard
    </a>
  </div>
</div>

<script>
  function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('collapsed');
    document.getElementById('mainContent').classList.toggle('collapsed');
    document.getElementById('toggleBtn').classList.toggle('collapsed');
  }
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>
<script>AOS.init();</script>

</body>
</html>
