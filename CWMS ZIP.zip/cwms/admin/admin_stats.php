<?php
session_start();
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header("Location: ../admin/admin_login.php");
    exit();
}

include '../includes/config.php';

$total_users = $dbh->query("SELECT COUNT(*) FROM customers")->fetchColumn();
$total_bookings = $dbh->query("SELECT COUNT(*) FROM bookings")->fetchColumn();
$total_services = $dbh->query("SELECT COUNT(*) FROM services")->fetchColumn();
$total_messages = $dbh->query("SELECT COUNT(*) FROM messages")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Admin Statistics</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />
  <link href="https://unpkg.com/aos@2.3.4/dist/aos.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet" />
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f8f9fa;
      color: #212529;
      margin: 0;
      padding: 0;
    }

    .sidebar {
      width: 260px;
      background-color: #f8f9fa;
      padding: 40px 20px;
      position: fixed;
      top: 0;
      bottom: 0;
      z-index: 1000;
      transition: transform 0.3s ease-in-out;
      border-right: 1px solid #dee2e6;
    }

    .sidebar.collapsed {
      transform: translateX(-100%);
    }

    .toggle-btn {
      position: fixed;
      top: 20px;
      left: 270px;
      z-index: 1100;
      background-color: #e7f5ff;
      border: none;
      color: #007bff;
      padding: 10px 14px;
      font-size: 18px;
      cursor: pointer;
      border-radius: 6px;
      transition: left 0.3s ease-in-out;
    }

    .sidebar.collapsed ~ .toggle-btn {
      left: 10px;
    }

    .sidebar h2 {
      text-align: center;
      font-size: 22px;
      margin-bottom: 30px;
      font-weight: 600;
      color: #007bff;
    }

    .sidebar a {
      text-decoration: none;
      color: #333;
      padding: 12px 18px;
      border-radius: 6px;
      margin-bottom: 14px;
      display: block;
      font-size: 15px;
      transition: background 0.3s;
    }

    .sidebar a:hover {
      background-color: #007bff;
      color: #fff;
    }

    .main-content {
      margin-left: 260px;
      padding: 50px;
      transition: margin-left 0.3s ease-in-out;
    }

    .main-content.collapsed {
      margin-left: 0;
    }

    .container-custom {
      background: #fff;
      padding: 40px;
      border-radius: 16px;
      box-shadow: 0 8px 32px rgba(0, 123, 255, 0.12);
      color: #212529;
    }

    h2 {
      text-align: center;
      color: #0d6efd;
      margin-bottom: 30px;
      font-weight: 600;
      font-size: 2.4rem;
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 30px;
    }

    .stat-card {
      background: #e9f0ff;
      padding: 30px 20px;
      border-radius: 12px;
      text-align: center;
      box-shadow: 0 6px 18px rgba(13, 110, 253, 0.15);
      color: #0d6efd;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .stat-card:hover {
      transform: translateY(-6px);
      box-shadow: 0 12px 24px rgba(13, 110, 253, 0.25);
    }

    .stat-card h4 {
      font-size: 1.2rem;
      margin-bottom: 12px;
    }

    .stat-card p {
      font-size: 2.5rem;
      font-weight: 700;
      color: #198754;
      margin: 0;
    }

    .stat-card a {
      display: inline-block;
      margin-top: 18px;
      font-size: 0.95rem;
      text-decoration: none;
      color: #0d6efd;
      border: 1px solid #0d6efd;
      padding: 10px 18px;
      border-radius: 6px;
      transition: background-color 0.3s ease, color 0.3s ease;
    }

    .stat-card a:hover {
      background-color: #0d6efd;
      color: white;
    }

    .btn-dashboard {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      margin-top: 40px;
      padding: 14px 28px;
      background-color: #0d6efd;
      color: white;
      border-radius: 8px;
      font-size: 1.1rem;
      font-weight: 600;
      text-decoration: none;
      box-shadow: 0 6px 12px rgba(13, 110, 253, 0.4);
      border: none;
      cursor: pointer;
      gap: 10px;
    }

    .btn-dashboard:hover {
      background-color: #084298;
      box-shadow: 0 8px 18px rgba(8, 66, 152, 0.6);
    }

    @media (max-width: 768px) {
      .main-content { margin-left: 0; padding: 30px 20px; }
      .sidebar { transform: translateX(-100%); }
    }
  </style>
</head>
<body>

<div class="sidebar" id="sidebar">
  <h2><i class="fas fa-gauge"></i> Admin Dashboard</h2>
  <a href="../index.php"><i class="fas fa-home me-2"></i>Home</a>
  <a href="manage_services.php"><i class="fas fa-concierge-bell me-2"></i>Manage Services</a>
  <a href="manage_users.php"><i class="fas fa-users-cog me-2"></i>Manage Users</a>
  <a href="view_bookings.php"><i class="fas fa-calendar-check me-2"></i>View All Bookings</a>
  <a href="admin_stats.php"><i class="fas fa-chart-line me-2"></i>View Statistics</a>
  <a href="admin_messages.php"><i class="fas fa-envelope me-2"></i>Contact Messages</a>
  <a href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
</div>

<button class="toggle-btn" onclick="toggleSidebar()" id="toggleBtn"><i class="fas fa-bars"></i></button>

<div class="main-content" id="mainContent" data-aos="fade-up">
  <div class="container-custom">
    <h2><i class="fas fa-chart-bar me-2"></i> Admin Statistics</h2>

    <div class="stats-grid">
      <div class="stat-card">
        <h4><i class="fas fa-users me-1"></i> Total Users</h4>
        <p><?= $total_users; ?></p>
        <a href="manage_users.php"><i class="fas fa-cogs me-1"></i> Manage Users</a>
      </div>
      <div class="stat-card">
        <h4><i class="fas fa-calendar-check me-1"></i> Total Bookings</h4>
        <p><?= $total_bookings; ?></p>
        <a href="view_bookings.php"><i class="fas fa-eye me-1"></i> View Bookings</a>
      </div>
      <div class="stat-card">
        <h4><i class="fas fa-tools me-1"></i> Total Services</h4>
        <p><?= $total_services; ?></p>
        <a href="manage_services.php"><i class="fas fa-eye me-1"></i> View Services</a>
      </div>
      <div class="stat-card">
        <h4><i class="fas fa-envelope me-1"></i> Total Messages</h4>
        <p><?= $total_messages; ?></p>
        <a href="admin_messages.php"><i class="fas fa-eye me-1"></i> View Messages</a>
      </div>
    </div>

    <a href="admin_dashboard.php" class="btn-dashboard mt-5">
      <i class="fas fa-tachometer-alt"></i> Go to Admin Dashboard
    </a>
  </div>
</div>

<script>
  function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('collapsed');
    document.getElementById('mainContent').classList.toggle('collapsed');
    document.getElementById('toggleBtn').classList.toggle('collapsed');
  }
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>
<script>AOS.init();</script>

</body>
</html>
