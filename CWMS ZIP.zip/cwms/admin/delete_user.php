<?php
session_start();

// Protect the page - only logged-in users can proceed
if (!isset($_SESSION['user_name'])) {
    header("Location: user_login.html");
    exit();
}

include '../includes/config.php';

// Get user/customer Name from the URL
$customer_id = $_GET['id'] ?? null;

if (!$customer_id) {
    die("Error: Customer name is missing.");
}

// Confirm the customer exists
$stmt = $dbh->prepare("SELECT * FROM customers WHERE customer_name = ?");
$stmt->execute([$customer_id]);
$user = $stmt->fetch();

if (!$user) {
    die("Error: Customer not found.");
}

// Delete the customer
$delete = $dbh->prepare("DELETE FROM customers WHERE customer_name = ?");
$delete->execute([$customer_id]);

echo "<script>alert('User deleted successfully.'); window.location='manage_users.php';</script>";
exit();
?>
