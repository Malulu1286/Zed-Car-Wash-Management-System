<?php
include '../includes/config.php';

$admin_name = "Zakaria";
$email = "zakaria@gmail.com";
$hashed_password = password_hash("12345", PASSWORD_DEFAULT); // Use a strong password

$stmt = $dbh->prepare("INSERT INTO admins (admin_name, email, password) VALUES (?, ?, ?)");
$stmt->execute([$admin_name, $email, $hashed_password]);

echo "Admin inserted.";
?>
