<?php
include '../includes/config.php';

$service_id = $_GET['name'] ?? null;
$message = '';
$error = '';

if (!$service_id) {
    $error = "Error: Service name is missing.";
} else {
    // Check if service exists
    $stmt = $dbh->prepare("SELECT * FROM services WHERE service_name = ?");
    $stmt->execute([$service_id]);
    $service = $stmt->fetch();

    if (!$service) {
        $error = "Error: Service not found.";
    } else {
        // Delete service
        $delete = $dbh->prepare("DELETE FROM services WHERE service_name = ?");
        $delete->execute([$service_id]);
        $message = "Service deleted successfully. Redirecting...";
        echo "<script>setTimeout(function() { window.location.href = 'manage_services.php'; }, 2000);</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Delete Service</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <!-- FontAwesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet" />

  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f8f9fa;
      color: #333;
      min-height: 100vh;
    }

    .container-custom {
      max-width: 600px;
      margin: 100px auto;
      padding: 40px;
      background-color: #ffffff;
      border-radius: 16px;
      box-shadow: 0 12px 48px rgba(0, 191, 255, 0.1);
      text-align: center;
    }

    h2 {
      font-weight: 600;
      color: #007bff;
      margin-bottom: 25px;
    }

    .alert {
      font-size: 1rem;
      padding: 15px;
      border-radius: 10px;
    }

    .alert-success {
      background-color: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }

    .alert-danger {
      background-color: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }

    footer {
      text-align: center;
      margin-top: 60px;
      padding: 20px;
      font-size: 0.9rem;
      color: #777;
      background-color: #f1f1f1;
    }

    @media (max-width: 600px) {
      .container-custom {
        margin: 60px 20px;
        padding: 30px 20px;
      }
    }
  </style>
</head>
<body>

  <div class="container-custom">
    <h2><i class="fas fa-trash-alt me-2"></i>Delete Service</h2>

    <?php if ($message): ?>
      <div class="alert alert-success"><?= $message ?></div>
    <?php elseif ($error): ?>
      <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <p class="mt-3">You will be redirected shortly...</p>
  </div>

  <footer>
    <p>&copy; 2025 Zed Group of Companies</p>
  </footer>

</body>
</html>
