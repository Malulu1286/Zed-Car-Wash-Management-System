<?php
include '../includes/config.php';

$booking_id = $_GET['id'] ?? null;
if (!$booking_id) {
    die("Booking ID missing.");
}

$stmt = $dbh->prepare("DELETE FROM bookings WHERE booking_id = ?");
$stmt->execute([$booking_id]);

echo "<script>alert('Booking deleted successfully.'); window.location='view_bookings.php';</script>";
?>
