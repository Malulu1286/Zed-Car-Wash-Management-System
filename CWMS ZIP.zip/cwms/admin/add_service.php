<?php
include '../includes/config.php';

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $service_name = $_POST['service_name'] ?? '';
    $description  = $_POST['description'] ?? '';
    $price        = $_POST['price'] ?? '';

    if (empty($service_name) || empty($description) || empty($price)) {
        $error = "All fields are required.";
    } else {
        try {
            $stmt = $dbh->prepare("INSERT INTO services (service_name, description, price) VALUES (?, ?, ?)");
            $stmt->execute([$service_name, $description, $price]);
            $success = "Service added successfully. Redirecting...";
            echo "<script>setTimeout(function() { window.location.href = 'manage_services.php'; }, 2000);</script>";
        } catch (PDOException $e) {
            $error = "Error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Add New Service</title>

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <!-- FontAwesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />
  <!-- AOS -->
  <link href="https://unpkg.com/aos@2.3.4/dist/aos.css" rel="stylesheet" />
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet" />

  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f8f9fa;
      color: #333;
      min-height: 100vh;
    }

    .container-custom {
      max-width: 700px;
      margin: 80px auto;
      padding: 50px 40px;
      background-color: #ffffff;
      border-radius: 16px;
      box-shadow: 0 12px 48px rgba(0, 191, 255, 0.1);
    }

    h2 {
      color: #007bff;
      text-align: center;
      margin-bottom: 30px;
    }

    label {
      font-weight: 600;
      margin-top: 15px;
    }

    input[type="text"],
    input[type="number"],
    textarea {
      width: 100%;
      padding: 12px;
      border-radius: 8px;
      border: 1px solid #ced4da;
      font-size: 1rem;
      background-color: #fff;
      color: #333;
      resize: vertical;
      box-shadow: inset 0 0 3px rgba(0, 0, 0, 0.05);
    }

    input:focus,
    textarea:focus {
      outline: none;
      border-color: #007bff;
      box-shadow: 0 0 8px rgba(0, 123, 255, 0.2);
    }

    button {
      margin-top: 25px;
      width: 100%;
      background-color: #28a745;
      border: none;
      padding: 12px;
      border-radius: 8px;
      font-size: 1.1rem;
      color: white;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    button:hover {
      background-color: #218838;
    }

    .back-link {
      display: block;
      margin-top: 20px;
      text-align: center;
      color: #007bff;
      font-weight: 500;
      text-decoration: none;
    }

    .back-link:hover {
      text-decoration: underline;
    }

    .alert {
      margin-top: 20px;
      padding: 15px;
      border-radius: 8px;
      font-size: 0.95rem;
    }

    .alert-success {
      background-color: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }

    .alert-danger {
      background-color: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }

    footer {
      text-align: center;
      padding: 20px 0;
      color: #777;
      background-color: #f1f1f1;
      font-size: 0.9rem;
      margin-top: 60px;
    }

    @media (max-width: 700px) {
      .container-custom {
        margin: 40px 20px;
        padding: 25px;
      }

      h2 {
        font-size: 1.5rem;
      }
    }
  </style>
</head>
<body>

<div class="container-custom" data-aos="fade-up">
  <h2><i class="fas fa-plus-circle me-2"></i>Add New Service</h2>

  <?php if (!empty($success)): ?>
    <div class="alert alert-success text-center"><?= $success ?></div>
  <?php elseif (!empty($error)): ?>
    <div class="alert alert-danger text-center"><?= $error ?></div>
  <?php endif; ?>

  <form method="POST" novalidate>
    <label for="service_name">Service Name:</label>
    <input type="text" name="service_name" id="service_name" required autocomplete="off" />

    <label for="description">Description:</label>
    <textarea name="description" id="description" rows="4" required></textarea>

    <label for="price">Price (TZS):</label>
    <input type="number" name="price" id="price" min="1000" required />

    <button type="submit"><i class="fas fa-check-circle me-1"></i> Add Service</button>
  </form>

  <a href="manage_services.php" class="back-link"><i class="fas fa-arrow-left me-1"></i> Back to Services</a>
</div>

<footer>
  <p>&copy; 2025 Zed Group of Companies</p>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- AOS JS -->
<script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init();
</script>

</body>
</html>
