<?php
$host = 'localhost';
$db = 'cwms';         // Your database name
$user = 'root';       // Default XAMPP MySQL username
$pass = '';           // Default XAMPP MySQL has no password

try {
    $dbh = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    exit();
}
?>
